# Index birmovanca

Univerzálna aplikácia pre prípravu na birmovku (kaplan, animátor, birmovanec). Capacitor + Firebase (anonymné prihlásenie + Firestore).

Začni súborom **NAVOD-FIREBASE.md**. Texty pre obchod sú v **PLAY-LISTING.md**.

## Vývoj
- `npm ci` · `npm run build` (webová časť do `www/`) · `npx cap sync android`
- Skúšobná zostava bez Firebase: `node build.mjs --mock` (výstup `www-test/`, pamäť v prehliadači) a test `python3 test/e2e.py` (Playwright).
- Konfigurácia: `src/firebase-config.js`. Pravidlá databázy: `firestore.rules`.
- Android build: workflow `.github/workflows/build.yml`.

## Štruktúra
- `src/calendar.js`: Veľká noc, nedele, prikázané sviatky pre ľubovoľný rok
- `src/actions.js`: práca s databázou · `src/views.js`, `src/sheets.js`: obrazovky a spodné okná
- `docs/`: úvodná stránka pre QR odkazy a zásady súkromia (GitHub Pages)
