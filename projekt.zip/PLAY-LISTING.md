# Podklady pre Google Play

## Základné údaje
- Názov: **Index birmovanca**
- Balík: `sk.indexbirmovanca.app`
- Kategória: Životný štýl (alebo Knihy a literatúra; vhodnejšie Lifestyle)
- Kontakt: emmkejjstudio@gmail.com
- Zásady súkromia: https://emmkejjstudio.github.io/index-birmovanca/privacy.html
- Cena: zadarmo, bez reklám, bez nákupov v aplikácii

## Krátky popis (max 80 znakov), SK
Digitálny index na prípravu na birmovku: omše, služby, zmierenie, skupiny.

## Úplný popis, SK
Index birmovanca nahrádza papierový index prípravy na sviatosť birmovania. Hodí sa do ktorejkoľvek farnosti a na ktorýkoľvek rok.

Kaplan alebo iná poverená osoba:
- založí farnosť, nastaví obdobie prípravy a vytvorí skupiny
- vygeneruje QR kód, ktorým sa birmovanci pripoja, a ich pripojenie potvrdí
- potvrdzuje záznamy o účasti na svätých omšiach, službách, sviatosti zmierenia a 7 darov
- posiela oznamy a PDF dokumenty skupine
- poverí animátorov, ktorí pomáhajú so skupinou
- kedykoľvek stiahne prehľady do PDF
- po skončení prípravy zmaže skupinu aj všetky údaje

Birmovanec:
- pripojí sa cez QR kód a vyberie svoju skupinu
- zapisuje si nedele a prikázané sviatky (kalendár sa počíta automaticky pre každý rok, vrátane pohyblivých sviatkov)
- sleduje, čo mu kaplan potvrdil
- číta oznamy a chatuje v skupine

Súkromie: aplikácia ukladá iba meno a priezvisko. Žiadne e-maily, telefónne čísla, adresy ani rodné čísla. Chat je len skupinový, bez súkromných správ, správy sa dajú nahlásiť a moderátor ich môže zmazať.

## Short description (EN)
Digital confirmation-preparation record: Mass attendance, services, groups.

## Full description (EN)
Index birmovanca is a digital record for Catholic confirmation preparation, usable in any parish and any year. A priest or coordinator creates groups and a QR code; candidates join, log Sunday and holy-day Masses (the liturgical calendar is computed automatically), services and confession, and the priest confirms them. Includes announcements, PDF documents, group text chat with moderation, and PDF export. Only a first and last name are stored. Interface language: Slovak.

## Data safety (Bezpečnosť údajov)
- Zhromažďuje sa: **Osobné údaje → Meno** (meno a priezvisko), **Správy → Iné správy v aplikácii** (chat), **Aktivita v aplikácii → Iná aktivita v aplikácii** (záznamy o účasti).
- Údaje sa **nezdieľajú** s tretími stranami (Firebase/Google je spracovateľ).
- Šifrované pri prenose: **Áno**.
- Používateľ môže požiadať o zmazanie: **Áno** (v aplikácii: Viac → Zmazať moje údaje; kaplan maže skupiny/farnosť; e-mail kontaktu).
- Povinné: Meno je povinné, aplikácia bez neho nefunguje.
- Účel: Funkčnosť aplikácie. Nie reklama ani analytika.
- Zmazanie účtu (Play politika): URL pre žiadosť o zmazanie môže byť stránka zásad súkromia (sekcia "Ako dlho údaje uchovávame a ako ich zmazať").

## Cieľová skupina a obsah
- Cieľová skupina: **13 až 15, 16 až 17 a 18+** (nevyberaj skupiny pod 13 rokov, inak sa pridajú prísne pravidlá pre deti).
- Neoznačuj aplikáciu ako určenú primárne deťom.
- Dotazník ratingu: žiadne násilie, sex, hazard, drogy. **Používateľmi vytvorený obsah: Áno** (textový chat) → ochrana: nahlásenie a mazanie správ, moderátor.
- Reklamy: Nie.
- Aplikácia nepoužíva povolenia okrem fotoaparátu (čítanie QR) a internetu.
- Prístup k aplikácii: bez prihlasovacích údajov, nepotrebuješ dávať Googlu testovací účet.

## Poznámka k UGC (obsah vytváraný používateľmi)
Google Play vyžaduje: pravidlá používania, spôsob nahlásenia obsahu a moderáciu. V aplikácii je tlačidlo na nahlásenie správy, kaplan vidí hlásenia v časti "Riešiť" a môže stíšiť alebo odstrániť člena.

## Texty "Čo je nové"
Prvé vydanie.
