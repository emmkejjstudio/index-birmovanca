import { esc } from './util.js';
export const ov = document.getElementById('ov');
export const sheet = document.getElementById('sheet');
let closers = [];
export function onClose(fn) { closers.push(fn); }
export function openSheet(html) {
  runClosers(); sheet.innerHTML = html; ov.hidden = false; sheet.scrollTop = 0;
  const f = sheet.querySelector('input:not([type=checkbox]):not([type=radio]):not([type=file]),textarea');
  if (f && matchMedia('(pointer:fine)').matches) f.focus();
}
function runClosers() { const c = closers; closers = []; c.forEach((f) => { try { f(); } catch (e) {} }); }
export function closeSheet() { runClosers(); ov.hidden = true; sheet.innerHTML = ''; }
ov.addEventListener('click', (e) => { if (e.target === ov) closeSheet(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !ov.hidden) closeSheet(); });
export function notice(title, text, extra) {
  openSheet('<h3>' + esc(title) + '</h3><p class="hint">' + esc(text) + '</p>' + (extra || '') + '<div class="btns"><button class="btn plain" data-do="close">Zavrieť</button></div>');
}
export function setErr(msg) { const e = document.getElementById('f-err'); if (e) e.textContent = msg || ''; }
export function busy(btn, on) { if (btn) { btn.disabled = !!on; } }
