import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, onAuthStateChanged } from 'firebase/auth';
import { initializeFirestore, doc, getDoc, setDoc, updateDoc, deleteDoc, collection, query, where, orderBy, limit, onSnapshot, getDocs, writeBatch, serverTimestamp, deleteField } from 'firebase/firestore';
import { firebaseConfig } from './firebase-config.js';

const MOCK = typeof __MOCK__ !== 'undefined' && __MOCK__;
export const configMissing = !MOCK && /DOPLN/.test(firebaseConfig.apiKey + firebaseConfig.projectId);
let app, auth, db;
if (!configMissing) {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = initializeFirestore(app, { experimentalAutoDetectLongPolling: true });
}
export { auth, db, doc, getDoc, setDoc, updateDoc, deleteDoc, collection, query, where, orderBy, limit, onSnapshot, getDocs, writeBatch, serverTimestamp, deleteField };
export function signIn() {
  return new Promise((resolve, reject) => {
    onAuthStateChanged(auth, (u) => { if (u) resolve(u); });
    signInAnonymously(auth).catch(reject);
  });
}
// skratky na cesty
export const pRef = (pid) => doc(db, 'parishes', pid);
export const col = (pid, ...p) => collection(db, 'parishes', pid, ...p);
export const dref = (pid, ...p) => doc(db, 'parishes', pid, ...p);
