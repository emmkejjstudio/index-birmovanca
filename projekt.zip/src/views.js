// Vykresľovanie obrazoviek (HTML reťazce) podľa roly používateľa.
import { S, planOf, isOwner, isAnimator, isCandidate, myGroup, groupName, unreadChat } from './store.js';
import { esc, MONTHS, SHORT, todayISO, parts, weekday, longDate, fmtTime, fmtAt, tms, pad2, fmtCode } from './util.js';

export const STYPES = { lektor: 'Lektor', ministrant: 'Ministrant', modlitby: 'Spoločné modlitby', dary: 'Obetné dary', ina: 'Iná služba / aktivita' };
export const GIFTS = ['Múdrosť', 'Rozum', 'Rada', 'Sila', 'Poznanie', 'Nábožnosť', 'Bázeň pred Bohom'];
export const svcName = (x) => (x.type === 'ina' && x.custom ? x.custom : STYPES[x.type] || 'Služba');

const ICON = {
  index: '<svg viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M8 3v4M16 3v4M3.5 10h17M9 15l2 2 4-4"/></svg>',
  people: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M3 19c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><circle cx="17" cy="9" r="2.4"/><path d="M16.5 14c2.6 0 4.5 1.7 4.5 4.2"/></svg>',
  chat: '<svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/></svg>',
  news: '<svg viewBox="0 0 24 24"><path d="M5 17V9a7 7 0 0 1 14 0v8l1.5 2h-17z"/><path d="M10 21h4"/></svg>',
  issues: '<svg viewBox="0 0 24 24"><path d="M12 3l9 16H3z"/><path d="M12 10v4M12 17v.5"/></svg>',
  parish: '<svg viewBox="0 0 24 24"><path d="M12 3v5M10 5.5h4M5 21V12l7-4 7 4v9z"/><path d="M10 21v-5h4v5"/></svg>',
  more: '<svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/></svg>'
};
export function tabsFor() {
  if (!S.me || S.me.status === 'pending') return [];
  if (isOwner()) return [['people', 'Ľudia'], ['chat', 'Chat'], ['news', 'Oznamy'], ['issues', 'Riešiť'], ['parish', 'Farnosť']];
  if (isAnimator()) return [['people', 'Skupina'], ['chat', 'Chat'], ['news', 'Oznamy'], ['more', 'Viac']];
  return [['index', 'Index'], ['chat', 'Chat'], ['news', 'Oznamy'], ['more', 'Viac']];
}
export function defaultTab() { const t = tabsFor(); return t.length ? t[0][0] : ''; }
const seg = (key, items, cur) => '<div class="seg">' + items.map((i) => '<button data-seg="' + key + '|' + i[0] + '" aria-pressed="' + (cur === i[0]) + '">' + esc(i[1]) + '</button>').join('') + '</div>';
export const segVal = (key, dflt) => S.seg[key] || dflt;

function chip(rec, missing) {
  if (rec && rec.confirmed) return '<span class="chip ok">Potvrdené</span>';
  if (rec) return '<span class="chip wait">Čaká na schválenie</span>';
  if (missing) return '<span class="chip miss">Chýba</span>';
  return '<span class="chip none">Zapísať</span>';
}
const confBy = (r) => (r && r.confirmed ? ' · ' + esc(r.confirmed.by) : '');

// ---------- počty pre hlavičku ----------
export function counts() {
  const { plan, months } = planOf(S.parish), R = S.records, t = todayISO();
  let m = 0, c = 0, s = 0, pend = 0;
  plan.forEach((p) => { if (R['m_' + p.date]) m++; });
  months.forEach((k) => { if (R['c_' + k]) c++; });
  Object.keys(R).forEach((k) => { if (k.startsWith('s_')) s++; if (!k.startsWith('g_') && !R[k].confirmed) pend++; });
  return { m, mt: plan.length, c, ct: months.length, s, pend, t };
}
function stat(n, total, label, frac) { return '<div class="stat"><div class="n">' + n + ' <small>/ ' + total + '</small></div><div class="l">' + label + '</div><div class="bar"><i style="width:' + Math.round(frac * 100) + '%"></i></div></div>'; }

export function header() {
  const p = S.parish, me = S.me;
  let h = '<header class="top"><div class="eyebrow"><span>' + esc(p ? p.name : '') + '</span><span>' + esc(p && p.from ? p.from.slice(0, 4) + '/' + (+p.to.slice(0, 4)) : '') + '</span></div><h1>Index birmovanca</h1>';
  h += '<div class="who"><b>' + esc(me.name) + '</b>' + (me.role === 'owner' ? '<span>' + esc((p && p.ownerTitle) || 'správca skupiny') + '</span>' : me.role === 'animator' ? '<span>animátor · ' + esc(groupName(me.groupId)) + '</span>' : '<span>' + esc(groupName(me.groupId)) + '</span>') + '</div>';
  if (isCandidate() && me.status !== 'pending') {
    const c = counts();
    h += '<div class="stats">' + stat(c.m, c.mt, 'Omše', c.mt ? c.m / c.mt : 0) + stat(c.c, c.ct, 'Spoveď', c.ct ? c.c / c.ct : 0) + '<div class="stat"><div class="n">' + c.s + '</div><div class="l">Služby</div></div></div>';
  } else if (isOwner()) {
    const act = S.members.filter((m) => m.role !== 'owner' && m.status !== 'pending').length, pend = S.members.filter((m) => m.status === 'pending').length;
    h += '<div class="stats"><div class="stat"><div class="n">' + act + '</div><div class="l">Členovia</div></div><div class="stat"><div class="n">' + pend + '</div><div class="l">Čakajú</div></div><div class="stat"><div class="n">' + S.groups.length + '</div><div class="l">Skupiny</div></div></div>';
  }
  return h + '</header>';
}

export function nav() {
  const tabs = tabsFor(); if (!tabs.length) return '';
  const issues = S.issues.length, unread = unreadChat();
  let h = '<nav class="tabs"><div>';
  tabs.forEach((t) => {
    const badge = t[0] === 'issues' && issues ? '<i class="dot">' + issues + '</i>' : t[0] === 'chat' && unread ? '<i class="dot">•</i>' : t[0] === 'people' && isOwner() && S.members.some((m) => m.status === 'pending') ? '<i class="dot">!</i>' : '';
    h += '<button data-tab="' + t[0] + '"' + (S.tab === t[0] ? ' aria-current="page"' : '') + '>' + (ICON[t[0] === 'more' ? 'more' : t[0]] || ICON.more) + '<span>' + t[1] + '</span>' + badge + '</button>';
  });
  return h + '</div></nav>';
}

// ---------- úvodná obrazovka ----------
export function viewWelcome(msg) {
  return '<div class="hero"><div class="eyebrow">Farnosť · príprava na birmovku</div><h1>Index birmovanca</h1>'
    + '<p class="hint">Digitálny index: účasť na omšiach, služby, sviatosť zmierenia a 7 darov. Záznamy potvrdzuje správca skupiny. Ukladá sa len meno a priezvisko.</p>'
    + (msg ? '<div class="warnbox">' + esc(msg) + '</div>' : '')
    + '<button class="btn" data-act="joinStart">Som birmovanec: pripojiť sa do skupiny</button>'
    + '<button class="btn ghost" data-act="animStart">Som animátor: mám pozvánku</button>'
    + '<button class="btn ghost" data-act="setupStart">Zakladám farnosť (kaplan, farár, katechéta…)</button>'
    + '<button class="btn plain" data-act="restoreStart">Mám kód obnovy (nový telefón správcu skupiny)</button>'
    + '<p class="hint" style="margin-top:auto;padding-top:18px">Prihlásenie je anonymné, netreba e-mail ani heslo. Tvoje údaje môžeš kedykoľvek zmazať v záložke Viac.</p></div>';
}
export function viewConfigMissing() {
  return '<div class="hero"><h1>Index birmovanca</h1><div class="warnbox">Aplikácia ešte nie je prepojená s databázou. Doplň Firebase nastavenia podľa súboru NAVOD-FIREBASE.md a zostav aplikáciu znova.</div></div>';
}
export function viewPending() {
  const g = myGroup();
  return '<div class="hero"><div class="eyebrow">' + esc(S.parish ? S.parish.name : '') + '</div><h1>Čakáš na potvrdenie</h1>'
    + '<div class="card"><p class="hint">Tvoju žiadosť o pripojenie do skupiny <b>' + esc(g ? g.name : '') + '</b> dostal správca skupiny. Keď ťa potvrdí, otvorí sa ti index a chat skupiny. Otvor aplikáciu neskôr alebo ju nechaj otvorenú.</p><dl class="kv"><dt>Meno</dt><dd>' + esc(S.me.name) + '</dd><dt>Skupina</dt><dd>' + esc(g ? g.name : '') + '</dd></dl></div>'
    + '<div class="btns"><button class="btn danger" data-act="leave">Zrušiť žiadosť</button></div></div>';
}

// ---------- index birmovanca ----------
export function viewIndex() {
  const s = segVal('index', 'masses');
  let h = seg('index', [['masses', 'Omše'], ['services', 'Služby'], ['conf', 'Spoveď'], ['gifts', '7 darov']], s);
  if (S.me.status === 'muted') h += '';
  const c = counts();
  if (c.pend > 0) h = '<div class="infobox">Záznamy čakajúce na schválenie správcom skupiny: ' + c.pend + '. Počkaj na schválenie, správca ich potvrdí vo svojom telefóne.</div>' + h;
  return h + (s === 'masses' ? viewMasses() : s === 'services' ? viewServices() : s === 'conf' ? viewConf() : viewGifts());
}
function viewMasses() {
  const t = todayISO(), R = S.records, f = segVal('mfilter', 'all');
  let h = '<button class="btn wide" data-act="scan">Skenovať QR kód v sakristii</button>';
  h += '<div class="seg">' + [['all', 'Všetky'], ['missing', 'Chýbajú'], ['wait', 'Na potvrdenie']].map((x) => '<button data-seg="mfilter|' + x[0] + '" aria-pressed="' + (f === x[0]) + '">' + x[1] + '</button>').join('') + '</div>';
  let last = '', nextMarked = false, any = false;
  h += '<div class="list">';
  planOf(S.parish).plan.forEach((p) => {
    const d = p.date, r = R['m_' + d], future = d > t, missing = !r && !future && d < t;
    if (f === 'missing' && !(missing || (!r && d === t))) return;
    if (f === 'wait' && !(r && !r.confirmed)) return;
    any = true;
    const pr = parts(d), mk = pr.y + '-' + pr.m;
    if (mk !== last) { last = mk; h += '<div class="month">' + MONTHS[pr.m - 1] + ' ' + pr.y + '</div>'; }
    const isNext = !nextMarked && d >= t; if (isNext) nextMarked = true;
    h += '<button class="row' + (d === t ? ' today' : '') + '" data-mass="' + d + '"' + (future ? ' disabled' : '') + (isNext ? ' data-next="1"' : '') + '>'
      + '<span class="date"><b>' + pr.d + '</b><span>' + SHORT[pr.m - 1] + '</span></span>'
      + '<span class="info"><span class="t">' + weekday(d) + (d === t ? ' · dnes' : '') + '</span><span class="s">'
      + (r ? esc(r.place || '') + (r.via === 'qr' ? ' · QR' : '') + confBy(r) : (p.name ? esc(p.name) : future ? 'ešte nenastalo' : 'bez záznamu')) + '</span></span>'
      + (future ? '<span></span>' : chip(r, missing)) + '</button>';
  });
  h += '</div>';
  if (!any) h += '<p class="hint">Nič na zobrazenie.</p>';
  return h;
}
function viewServices() {
  const R = S.records;
  const list = Object.keys(R).filter((k) => k.startsWith('s_')).map((k) => ({ id: k, ...R[k] })).sort((a, b) => (a.date < b.date ? 1 : -1));
  let h = '<h2 class="sec">Služby pri omši a aktivity</h2><p class="hint">Lektor, ministrant, spoločné modlitby, obetné dary a iné služby alebo aktivity.</p><div class="btns"><button class="btn" data-act="addsvc">Pridať službu</button></div><div class="list">';
  list.forEach((s) => { const p = parts(s.date); h += '<button class="row" data-svc="' + s.id + '"><span class="date"><b>' + p.d + '</b><span>' + SHORT[p.m - 1] + '</span></span><span class="info"><span class="t">' + esc(svcName(s)) + '</span><span class="s">' + esc(s.place || '') + confBy(s) + '</span></span>' + chip(s, false) + '</button>'; });
  h += '</div>';
  if (!list.length) h += '<div class="card"><p class="hint">Zatiaľ nemáš zapísanú žiadnu službu. Po omši ju sem pridaj a daj potvrdiť správcovi skupiny.</p></div>';
  return h;
}
function viewConf() {
  const t = todayISO(), R = S.records, tm = t.slice(0, 7);
  let h = '<h2 class="sec">Sviatosť zmierenia</h2><p class="hint">Raz mesačne. Správca skupiny potvrdí každý mesiac.</p><div class="list">';
  planOf(S.parish).months.forEach((k) => {
    const y = +k.slice(0, 4), m = +k.slice(5, 7), r = R['c_' + k], future = k > tm, missing = !r && !future && k < tm;
    h += '<button class="row" data-conf="' + k + '"' + (future ? ' disabled' : '') + '><span class="date"><b>' + m + '.</b><span>' + y + '</span></span><span class="info"><span class="t">' + MONTHS[m - 1] + '</span><span class="s">' + (r ? esc(r.place || '') + ' · ' + longDate(r.date) + confBy(r) : future ? 'ešte nenastalo' : 'bez záznamu') + '</span></span>' + (future ? '<span></span>' : chip(r, missing)) + '</button>';
  });
  return h + '</div>';
}
function viewGifts() {
  const R = S.records;
  let h = '<h2 class="sec">7 darov Ducha Svätého</h2><p class="hint">Označ dar, ktorý už poznáš naspamäť.</p><div class="list">';
  GIFTS.forEach((g, i) => { h += '<div class="gift"><input type="checkbox" id="g' + i + '" data-gift="' + i + '"' + (R['g_' + i] ? ' checked' : '') + '><label for="g' + i + '">' + g + '</label></div>'; });
  return h + '</div>';
}

// ---------- ľudia ----------
export function viewPeople() {
  const owner = isOwner();
  let members = S.members.filter((m) => m.role !== 'owner');
  let h = '<h2 class="sec">' + (owner ? 'Ľudia vo farnosti' : 'Moja skupina') + '</h2>';
  if (owner && !S.groups.length) return h + '<div class="card"><p class="hint">Zatiaľ nemáš žiadnu skupinu. Vytvor prvú skupinu a potom pošli birmovancom QR kód farnosti.</p><div class="btns"><button class="btn" data-act="addgroup">Vytvoriť skupinu</button></div></div>';
  if (owner) {
    const cur = segVal('pgroup', 'all');
    h += seg('pgroup', [['all', 'Všetky']].concat(S.groups.map((g) => [g.id, g.name])), cur);
    if (cur !== 'all') members = members.filter((m) => m.groupId === cur);
  }
  const pend = members.filter((m) => m.status === 'pending');
  if (pend.length) h += '<div class="pending"><span>Čaká na potvrdenie: ' + pend.length + '</span></div>';
  members.sort((a, b) => (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) || (a.role === 'animator' ? 0 : 1) - (b.role === 'animator' ? 0 : 1) || a.name.localeCompare(b.name, 'sk'));
  h += '<div class="list">';
  members.forEach((m) => {
    const st = m.status === 'pending' ? '<span class="chip wait">Čaká</span>' : m.status === 'muted' ? '<span class="chip miss">Stlmený</span>' : '';
    h += '<button class="row noicon" data-member="' + m.id + '"><span class="info"><span class="t">' + esc(m.name) + (m.role === 'animator' ? '<span class="tag">animátor</span>' : '') + '</span><span class="s">' + esc(groupName(m.groupId)) + '</span></span>' + st + '</button>';
  });
  h += '</div>';
  if (!members.length) h += '<div class="card"><p class="hint">' + (owner ? 'V tejto skupine zatiaľ nikto nie je. Pošli birmovancom QR kód farnosti (záložka Farnosť).' : 'Skupina zatiaľ nemá členov.') + '</p></div>';
  if (members.some((m) => m.role === 'candidate' && m.status !== 'pending')) h += '<div class="btns"><button class="btn ghost" data-act="exportGroup">Prehľad skupiny do PDF</button></div>';
  return h;
}

// ---------- chat ----------
export function viewChat() {
  if (isOwner() && !S.chatGid) {
    let h = '<h2 class="sec">Chat skupín</h2><p class="hint">Vyber skupinu. Chat je len textový a vidia ho len členovia skupiny a správca skupiny.</p><div class="list">';
    S.groups.forEach((g) => { h += '<button class="row noicon" data-chat="' + g.id + '"><span class="info"><span class="t">' + esc(g.name) + '</span></span><span class="chip none">Otvoriť</span></button>'; });
    if (!S.groups.length) h += '<div class="card"><p class="hint">Najprv vytvor skupinu.</p></div>';
    return h + '</div>';
  }
  const gid = S.chatGid || (S.me && S.me.groupId);
  const muted = S.me.status === 'muted';
  let h = '<div class="btns" style="justify-content:space-between;align-items:center"><h2 class="sec">' + esc(groupName(gid)) + '</h2>' + (isOwner() ? '<button class="btn small plain" data-act="chatback">Zmeniť skupinu</button>' : '') + '</div>';
  h += '<div class="chatbox" id="chatbox">' + chatList() + '</div>';
  h += muted ? '<p class="hint">Si dočasne stlmený, môžeš chat čítať, ale nie písať.</p>'
    : '<div class="composer"><div><textarea id="chat-in" rows="1" maxlength="500" placeholder="Napíš správu skupine"></textarea><button class="btn" data-act="send">Poslať</button></div></div><div style="height:64px"></div>';
  return h;
}
export function chatList() {
  if (!S.msgs.length) return '<p class="hint">Zatiaľ tu nie sú žiadne správy.</p>';
  return S.msgs.map((m) => '<button class="msg' + (m.uid === S.uid ? ' mine' : '') + '" data-msg="' + m.id + '"><span class="who">' + esc(m.name) + (m.role === 'owner' ? ' · správca skupiny' : m.role === 'animator' ? ' · animátor' : '') + '</span>' + esc(m.text) + '<span class="when">' + fmtTime(m.at) + '</span></button>').join('');
}

// ---------- oznamy a dokumenty ----------
export function viewNews(docs) {
  const s = segVal('news', 'news');
  let h = seg('news', [['news', 'Oznamy'], ['docs', 'Dokumenty']], s);
  if (s === 'news') {
    const canPost = isOwner() || isAnimator();
    h += '<h2 class="sec">Oznamy</h2>' + (canPost ? '<div class="btns"><button class="btn" data-act="addnews">Nový oznam</button></div>' : '');
    h += '<div class="list">' + S.news.map((n) => '<button class="row noicon" data-news="' + n.id + '"><span class="info"><span class="t">' + esc(n.title || 'Oznam') + '</span><span class="s">' + esc(n.text.length > 140 ? n.text.slice(0, 140) + '…' : n.text) + '</span><span class="s">' + esc(n.byName) + ' · ' + fmtAt(n.at) + (n.gid === 'all' ? ' · všetky skupiny' : isOwner() ? ' · ' + esc(groupName(n.gid)) : '') + '</span></span></button>').join('') + '</div>';
    if (!S.news.length) h += '<div class="card"><p class="hint">Zatiaľ nemáš žiadne oznamy.</p></div>';
    return h;
  }
  const g = S.docGroup || (S.me.groupId || (S.groups[0] && S.groups[0].id));
  const gd = S.groups.find((x) => x.id === g);
  const canUp = isOwner() || (isAnimator() && gd && gd.animDocs);
  h += '<h2 class="sec">Dokumenty</h2>';
  if (isOwner()) h += '<div class="field"><label for="docgroup">Skupina</label><select id="docgroup">' + S.groups.map((x) => '<option value="' + x.id + '"' + (x.id === g ? ' selected' : '') + '>' + esc(x.name) + '</option>').join('') + '</select></div>';
  if (canUp) h += '<div class="btns"><button class="btn" data-act="adddoc">Nahrať PDF</button></div>';
  h += '<div class="list">' + (docs || []).map((d) => '<button class="row noicon" data-doc="' + d.id + '"><span class="info"><span class="t">' + esc(d.title) + '</span><span class="s">' + esc(d.byName) + ' · ' + fmtAt(d.at) + ' · ' + Math.max(1, Math.round(d.size / 1024)) + ' kB</span></span><span class="chip none">Otvoriť</span></button>').join('') + '</div>';
  if (docs && !docs.length) h += '<div class="card"><p class="hint">Zatiaľ tu nie sú žiadne dokumenty.</p></div>';
  if (!docs) h += '<p class="hint">Načítavam…</p>';
  return h;
}

// ---------- na vyriešenie ----------
export function viewIssues() {
  let h = '<h2 class="sec">Na vyriešenie</h2><p class="hint">Nahlásené správy a návrhy animátorov. Rozhodnutie je na tebe.</p><div class="list">';
  S.issues.forEach((i) => {
    const what = i.type === 'report' ? 'Nahlásená správa' : i.action === 'remove_member' ? 'Návrh: odstrániť člena' : i.action === 'mute' ? 'Návrh: stlmiť člena' : 'Návrh: zmazať skupinu';
    h += '<button class="row noicon" data-issue="' + i.id + '"><span class="info"><span class="t">' + what + '</span><span class="s">' + esc(groupName(i.gid)) + ' · ' + esc(i.byName) + (i.targetName ? ' · ' + esc(i.targetName) : '') + '</span></span><span class="chip wait">Riešiť</span></button>';
  });
  h += '</div>';
  if (!S.issues.length) h += '<div class="card"><p class="hint">Nič nečaká na vyriešenie.</p></div>';
  return h;
}

// ---------- farnosť (správca skupiny) ----------
export function viewParish() {
  const p = S.parish;
  let h = '<h2 class="sec">Farnosť</h2>';
  h += '<div class="card"><b>' + esc(p.name) + '</b><dl class="kv"><dt>Kód farnosti</dt><dd><b>' + fmtCode(p.id) + '</b></dd><dt>Obdobie omší</dt><dd>' + longDate(p.from) + ' – ' + longDate(p.to) + '</dd><dt>Spoveď</dt><dd>' + p.confFrom.slice(5) + '/' + p.confFrom.slice(0, 4) + ' – ' + p.confTo.slice(5) + '/' + p.confTo.slice(0, 4) + '</dd></dl>'
    + '<div class="btns"><button class="btn" data-act="qrJoin">QR kód pre birmovancov</button><button class="btn ghost" data-act="qrMass">QR kód do sakristie</button></div>'
    + '<div class="btns"><button class="btn plain small" data-act="editParish">Upraviť názov, obdobie a sviatky</button></div></div>';
  h += '<div class="card"><b>Skupiny</b>';
  S.groups.forEach((g) => { const n = S.members.filter((m) => m.groupId === g.id).length; h += '<button class="row noicon" data-group="' + g.id + '"><span class="info"><span class="t">' + esc(g.name) + '</span><span class="s">Členov: ' + n + '</span></span><span class="chip none">Spravovať</span></button>'; });
  h += '<div class="btns"><button class="btn" data-act="addgroup">Pridať skupinu</button></div></div>';
  h += '<div class="card"><b>Export</b><p class="hint">Prehľad skupiny alebo index jedného birmovanca získaš do PDF kedykoľvek: v záložke Ľudia.</p><div class="btns"><button class="btn ghost" data-act="exportGroup">Prehľad skupiny do PDF</button></div></div>';
  h += '<div class="card"><b>Kód obnovy správcu skupiny</b><p class="hint">Keď vymeníš telefón alebo vymažeš údaje aplikácie, týmto kódom získaš farnosť späť. Zapíš si ho a neukazuj ho nikomu.</p><div class="btns"><button class="btn ghost" data-act="showRecovery">Zobraziť kód obnovy</button></div></div>';
  h += '<div class="card"><b>Moje meno</b><p class="hint">' + esc(S.me.name) + '</p><div class="btns"><button class="btn ghost" data-act="editName">Zmeniť meno</button></div></div>';
  h += '<div class="card"><b>O aplikácii</b><p class="hint">Ako aplikácia funguje, ochrana údajov, kontakt a podpora autora.</p><div class="btns"><button class="btn ghost" data-act="about">O aplikácii</button></div></div>';
  h += '<div class="card"><b>Zmazať farnosť</b><p class="hint">Natrvalo zmaže farnosť, všetky skupiny a údaje všetkých členov.</p><div class="btns"><button class="btn danger" data-act="delParish">Zmazať farnosť</button></div></div>';
  return h;
}
export function viewMore() {
  return '<h2 class="sec">Viac</h2>'
    + '<div class="card"><b>Meno</b><p class="hint">' + esc(S.me.name) + '</p><div class="btns"><button class="btn ghost" data-act="editName">Zmeniť meno</button></div></div>'
    + (isCandidate() ? '<div class="card"><b>Index do PDF</b><p class="hint">Stiahni si svoj index so všetkými záznamami a potvrdeniami.</p><div class="btns"><button class="btn ghost" data-act="exportMe">Index do PDF</button></div></div>' : '')
    + '<div class="card"><b>Chat a pravidlá</b><p class="hint">V chate sa správaj slušne. Nevhodné správy môžeš nahlásiť, ťuknutím na správu.</p></div>'
    + '<div class="card"><b>O aplikácii</b><p class="hint">Ako aplikácia funguje, ochrana údajov, kontakt a podpora autora.</p><div class="btns"><button class="btn ghost" data-act="about">O aplikácii</button></div></div>'
    + '<div class="card"><b>Ochrana údajov</b><p class="hint">Ukladá sa len tvoje meno a priezvisko, skupina a záznamy z indexu. Správca skupiny vidí údaje svojej farnosti. Údaje môžeš kedykoľvek zmazať.</p><div class="btns"><button class="btn danger" data-act="leave">Zmazať moje údaje a odísť</button></div></div>';
}

export function view() {
  if (S.me.status === 'pending') return viewPending();
  const t = S.tab;
  return t === 'index' ? viewIndex() : t === 'people' ? viewPeople() : t === 'chat' ? viewChat() : t === 'news' ? viewNews(S.docList) : t === 'issues' ? viewIssues() : t === 'parish' ? viewParish() : viewMore();
}
