// Všetky zápisy do databázy.
import { S, startParish } from './store.js';
import { db, auth, doc, getDoc, setDoc, updateDoc, deleteDoc, query, where, getDocs, writeBatch, serverTimestamp, pRef, col, dref } from './fb.js';
import { randCode, randToken, clean } from './util.js';
import { deliverFile, readFileBase64 } from './files.js';

const uid = () => S.uid;
const nowISO = () => new Date().toISOString();

// ---------- vstup do farnosti ----------
export async function fetchParish(pid) {
  const s = await getDoc(pRef(pid));
  return s.exists() ? { id: pid, ...s.data() } : null;
}
export async function fetchGroups(pid) {
  const s = await getDocs(col(pid, 'groups'));
  return s.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => a.name.localeCompare(b.name, 'sk'));
}
export async function fetchInvite(pid, token) {
  const s = await getDoc(dref(pid, 'invites', token));
  return s.exists() ? s.data() : null;
}
export async function createParish(o) {
  let pid = randCode(8);
  for (let i = 0; i < 5 && (await getDoc(pRef(pid))).exists(); i++) pid = randCode(8);
  const b = writeBatch(db);
  b.set(pRef(pid), { name: o.name, ownerTitle: o.ownerTitle, country: o.country, schoolYear: o.schoolYear, from: o.from, to: o.to, confFrom: o.confFrom, confTo: o.confTo, feasts: o.feasts, preset: o.preset, createdAt: serverTimestamp() });
  b.set(dref(pid, 'members', uid()), { name: o.ownerName, role: 'owner', groupId: null, status: 'active', createdAt: serverTimestamp() });
  await b.commit();
  await setDoc(dref(pid, 'secrets', randCode(12)), { at: nowISO() }); // kód obnovy
  startParish(pid);
  return pid;
}
export async function restoreOwner(pid, code, name) {
  await setDoc(dref(pid, 'members', uid()), { name, role: 'owner', groupId: null, status: 'active', createdAt: serverTimestamp(), recovery: code });
  startParish(pid);
}
export async function joinCandidate(pid, gid, name) {
  await setDoc(dref(pid, 'members', uid()), { name, role: 'candidate', groupId: gid, status: 'pending', createdAt: serverTimestamp() });
  startParish(pid);
}
export async function joinAnimator(pid, token, gid, name) {
  const b = writeBatch(db);
  b.set(dref(pid, 'members', uid()), { name, role: 'animator', groupId: gid, status: 'active', createdAt: serverTimestamp(), invite: token });
  b.delete(dref(pid, 'invites', token));
  await b.commit();
  startParish(pid);
}
export async function listSecrets() { const s = await getDocs(col(S.pid, 'secrets')); return s.docs.map((d) => d.id); }
export async function newRecoveryCode() {
  const old = await listSecrets();
  const c = randCode(12);
  await setDoc(dref(S.pid, 'secrets', c), { at: nowISO() });
  for (const o of old) await deleteDoc(dref(S.pid, 'secrets', o));
  return c;
}

// ---------- nastavenia farnosti a skupiny ----------
export const saveParish = (patch) => updateDoc(pRef(S.pid), patch);
export async function createGroup(name, animConfirm, animDocs) {
  const r = doc(col(S.pid, 'groups'));
  await setDoc(r, { name, animConfirm: !!animConfirm, animDocs: !!animDocs, createdAt: serverTimestamp() });
  return r.id;
}
export const updateGroup = (gid, patch) => updateDoc(dref(S.pid, 'groups', gid), patch);
export async function createInvite(gid) {
  const t = randToken();
  await setDoc(dref(S.pid, 'invites', t), { gid, at: serverTimestamp() });
  return t;
}
export async function listInvites(gid) {
  const s = await getDocs(query(col(S.pid, 'invites'), where('gid', '==', gid)));
  return s.docs.map((d) => d.id);
}
export const revokeInvite = (t) => deleteDoc(dref(S.pid, 'invites', t));

// ---------- mazanie ----------
async function deleteDocs(snap) {
  const docs = snap.docs;
  for (let i = 0; i < docs.length; i += 400) {
    const b = writeBatch(db);
    docs.slice(i, i + 400).forEach((d) => b.delete(d.ref));
    await b.commit();
  }
}
async function deleteMemberData(pid, mid) {
  await deleteDocs(await getDocs(col(pid, 'members', mid, 'records')));
  await deleteDoc(dref(pid, 'members', mid));
}
export async function deleteGroupData(pid, gid) {
  const members = await getDocs(query(col(pid, 'members'), where('groupId', '==', gid)));
  for (const m of members.docs) await deleteMemberData(pid, m.id);
  await deleteDocs(await getDocs(col(pid, 'groups', gid, 'messages')));
  await deleteDocs(await getDocs(query(col(pid, 'news'), where('gid', '==', gid))));
  const docs = await getDocs(query(col(pid, 'docs'), where('gid', '==', gid)));
  for (const d of docs.docs) { await deleteDoc(dref(pid, 'docdata', d.id)); await deleteDoc(d.ref); }
  await deleteDocs(await getDocs(query(col(pid, 'issues'), where('gid', '==', gid))));
  await deleteDocs(await getDocs(query(col(pid, 'invites'), where('gid', '==', gid))));
  await deleteDoc(dref(pid, 'groups', gid));
}
export async function deleteParishData() {
  const pid = S.pid;
  const groups = await getDocs(col(pid, 'groups'));
  for (const g of groups.docs) await deleteGroupData(pid, g.id);
  await deleteDocs(await getDocs(col(pid, 'news')));
  await deleteDocs(await getDocs(col(pid, 'issues')));
  await deleteDocs(await getDocs(col(pid, 'invites')));
  const members = await getDocs(col(pid, 'members'));
  for (const m of members.docs) if (m.id !== uid()) await deleteMemberData(pid, m.id);
  await deleteDocs(await getDocs(col(pid, 'secrets')));
  await deleteDoc(pRef(pid));
  await deleteDoc(dref(pid, 'members', uid()));
}
export async function removeMember(mid) { await deleteMemberData(S.pid, mid); }
export async function deleteMyData() {
  await deleteMemberData(S.pid, uid());
}

// ---------- členovia ----------
export const setMember = (mid, patch) => updateDoc(dref(S.pid, 'members', mid), patch);
export const confirmMember = (mid) => updateDoc(dref(S.pid, 'members', mid), { status: 'active' });
export async function getRecords(mid) {
  const s = await getDocs(col(S.pid, 'members', mid, 'records'));
  const r = {}; s.docs.forEach((d) => { r[d.id] = d.data(); }); return r;
}

// ---------- záznamy v indexe ----------
export const saveRecord = (id, data) => setDoc(dref(S.pid, 'members', uid(), 'records', id), { ...data, at: nowISO(), confirmed: null });
export const deleteRecord = (id) => deleteDoc(dref(S.pid, 'members', uid(), 'records', id));
export async function confirmRecords(mid, ids) {
  const c = { at: nowISO(), by: S.me.name, byUid: uid() };
  for (let i = 0; i < ids.length; i += 400) {
    const b = writeBatch(db);
    ids.slice(i, i + 400).forEach((id) => b.update(dref(S.pid, 'members', mid, 'records', id), { confirmed: c }));
    await b.commit();
  }
}

// ---------- chat ----------
export const sendMsg = (gid, text) => setDoc(doc(col(S.pid, 'groups', gid, 'messages')), { uid: uid(), name: S.me.name, role: S.me.role, text, at: serverTimestamp() });
export const deleteMsg = (gid, mid) => deleteDoc(dref(S.pid, 'groups', gid, 'messages', mid));
export const addIssue = (data) => setDoc(doc(col(S.pid, 'issues')), { ...data, by: uid(), byName: S.me.name, status: 'open', at: serverTimestamp() });
export const resolveIssue = (id) => deleteDoc(dref(S.pid, 'issues', id));

// ---------- oznamy a dokumenty ----------
export const postNews = (gid, title, text) => setDoc(doc(col(S.pid, 'news')), { gid, title, text, by: uid(), byName: S.me.name, at: serverTimestamp() });
export const deleteNews = (id) => deleteDoc(dref(S.pid, 'news', id));
export const MAX_DOC = 650000;
export async function uploadDoc(gid, title, file) {
  if (file.size > MAX_DOC) throw new Error('size');
  const data = await readFileBase64(file);
  const r = doc(col(S.pid, 'docs'));
  const b = writeBatch(db);
  b.set(r, { gid, title, fileName: file.name, size: file.size, by: uid(), byName: S.me.name, at: serverTimestamp() });
  b.set(dref(S.pid, 'docdata', r.id), { gid, data });
  await b.commit();
}
export async function listDocs(gid) {
  const s = await getDocs(query(col(S.pid, 'docs'), where('gid', '==', gid)));
  return s.docs.map((d) => ({ id: d.id, ...d.data() }));
}
export async function openDoc(d) {
  const s = await getDoc(dref(S.pid, 'docdata', d.id));
  if (!s.exists()) throw new Error('missing');
  await deliverFile(d.fileName || (d.title + '.pdf'), s.data().data, 'application/pdf');
}
export async function removeDoc(id) { await deleteDoc(dref(S.pid, 'docdata', id)); await deleteDoc(dref(S.pid, 'docs', id)); }
export { clean };
