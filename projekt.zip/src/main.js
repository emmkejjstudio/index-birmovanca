import '@fontsource/montserrat/latin-400.css'; import '@fontsource/montserrat/latin-ext-400.css';
import '@fontsource/montserrat/latin-500.css'; import '@fontsource/montserrat/latin-ext-500.css';
import '@fontsource/montserrat/latin-600.css'; import '@fontsource/montserrat/latin-ext-600.css';
import '@fontsource/montserrat/latin-700.css'; import '@fontsource/montserrat/latin-ext-700.css';
import '@fontsource/cormorant-garamond/latin-600.css'; import '@fontsource/cormorant-garamond/latin-ext-600.css';
import '@fontsource/cormorant-garamond/latin-700.css'; import '@fontsource/cormorant-garamond/latin-ext-700.css';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';
import { configMissing, signIn } from './fb.js';
import { S, hooks, startParish, stopAll, requestRender, openChat, closeChat, isOwner } from './store.js';
import * as V from './views.js';
import * as H from './sheets.js';
import { closeSheet, ov } from './ui.js';
import { $, pstore } from './util.js';

const app = document.getElementById('app');
let shown = '';
let scrolledMasses = false;

function render() {
  if (configMissing) { app.innerHTML = V.viewConfigMissing(); return; }
  if (!S.uid) { app.innerHTML = '<div class="hero"><h1>Index birmovanca</h1><p class="hint">' + (S.err ? S.err : 'Pripájam sa…') + '</p></div>'; return; }
  if (S.pid && S.me === null && !S.loading) { goWelcome('Tvoj záznam vo farnosti už neexistuje (správca skupiny ťa odstránil alebo si údaje zmazal).'); return; }
  if (S.gone) { goWelcome(S.gone); return; }
  if (!S.pid) { app.innerHTML = V.viewWelcome(S.welcomeMsg); return; }
  if (S.me === undefined || !S.parish) { app.innerHTML = '<div class="hero"><h1>Index birmovanca</h1><p class="hint">' + (S.err ? S.err : 'Načítavam…') + '</p></div>'; return; }
  const tabs = V.tabsFor().map((t) => t[0]);
  if (!tabs.includes(S.tab)) { S.tab = V.defaultTab(); }
  if (S.tab === 'news' && S.docList === undefined && V.segVal('news', 'news') === 'docs') H.refreshDocs();
  const chatIn = $('chat-in'), keep = chatIn ? { v: chatIn.value, f: document.activeElement === chatIn } : null;
  const y = window.scrollY;
  let h;
  if (S.me.status === 'pending') h = V.viewPending();
  else h = V.header() + '<main>' + (S.err ? '<div class="warnbox">' + S.err + '</div>' : '') + V.view() + '</main>' + V.nav();
  app.innerHTML = h;
  const ci = $('chat-in');
  if (keep && ci) { ci.value = keep.v; if (keep.f) ci.focus(); }
  if (S.tab === 'chat') { if (shown !== 'chat') window.scrollTo(0, document.body.scrollHeight); else window.scrollTo(0, y); }
  else if (S.tab === 'index' && V.segVal('index', 'masses') === 'masses' && !scrolledMasses) { scrolledMasses = true; const n = app.querySelector('[data-next]'); if (n) n.scrollIntoView({ block: 'center' }); }
  else window.scrollTo(0, y);
  shown = S.tab;
}
function goWelcome(msg) {
  stopAll(); S.pid = ''; S.gone = ''; S.tab = ''; S.welcomeMsg = msg || ''; S.docList = undefined;
  try { pstore.removeItem('ib_pid'); } catch (e) {}
  render();
}
function updateChat() {
  const b = $('chatbox'); if (!b) return;
  const near = window.innerHeight + window.scrollY >= document.body.scrollHeight - 160;
  b.innerHTML = V.chatList();
  if (near) window.scrollTo(0, document.body.scrollHeight);
}
hooks.render = render; hooks.chat = updateChat;

function setTab(t) {
  if (S.tab === 'chat' && t !== 'chat') closeChat();
  S.tab = t;
  if (t === 'chat' && S.me && !isOwner()) openChat(S.me.groupId);
  if (t === 'news' && V.segVal('news', 'news') === 'docs') H.refreshDocs();
  shown = ''; render(); if (t !== 'chat') window.scrollTo(0, 0);
}

// ---------- kliknutia ----------
const A = {
  joinStart: () => H.sheetJoinStart('join'), animStart: () => H.sheetJoinStart('anim'), setupStart: () => H.sheetSetup(), restoreStart: () => H.sheetRestore(),
  scan: () => H.sheetScanGeneric('mass'), addsvc: () => H.sheetSvc(null), leave: () => H.sheetLeave(), editName: () => H.sheetName(), name: () => H.sheetName(),
  qrJoin: () => H.sheetQR('join'), qrMass: () => H.sheetQR('mass'), editParish: () => H.sheetEditParish(), addgroup: () => H.sheetAddGroup(),
  exportGroup: () => H.exportGroup(), exportMe: () => H.exportMember(null), showRecovery: () => H.sheetRecovery(), delParish: () => H.sheetDeleteParish(),
  about: () => H.sheetAbout(), chatback: () => { closeChat(); render(); }, send: () => H.sendChat(), addnews: () => H.sheetAddNews(), adddoc: () => H.sheetAddDoc()
};
document.addEventListener('click', async (e) => {
  const b = e.target.closest('button'); if (!b) return;
  const g = (k) => b.getAttribute(k);
  let v;
  if ((v = g('data-tab'))) return setTab(v);
  if ((v = g('data-seg'))) { const a = v.split('|'); S.seg[a[0]] = a[1]; if (a[0] === 'news' && a[1] === 'docs') H.refreshDocs(); return render(); }
  if ((v = g('data-mass'))) return H.sheetMass(v);
  if ((v = g('data-svc'))) return H.sheetSvc(v);
  if ((v = g('data-conf'))) return H.sheetConf(v);
  if ((v = g('data-member'))) return H.sheetMember(v);
  if ((v = g('data-group'))) return H.sheetGroup(v);
  if ((v = g('data-chat'))) { openChat(v); return render(); }
  if ((v = g('data-msg'))) return H.sheetMsg(v);
  if ((v = g('data-news'))) return H.sheetNewsItem(v);
  if ((v = g('data-doc'))) { const d = (S.docList || []).find((x) => x.id === v); if (d) H.sheetDocItem(d); return; }
  if ((v = g('data-issue'))) return H.sheetIssue(v);
  if ((v = g('data-act'))) { if (A[v]) return A[v](); return; }
  const o = g('data-do'); if (!o) return;
  if (o === 'close') return closeSheet();
  if (o === 'qrpdf') { try { await H.qrPdfPublic(g('data-k'), g('data-t')); } catch (x) { console.error(x); } return; }
  if (o === 'qrshare') { try { await H.shareLinkPublic(g('data-k'), g('data-t')); } catch (x) { console.error(x); } return; }
  if (o === 'savename') return H.saveName();
  if (o === 'leaveDo') return H.leaveDo();
  if (o === 'proposeDo') return H.proposeDo(b);
  if (o === 'exportGroupPick') { const gid = (document.querySelector('input[name=grp]:checked') || {}).value; if (!gid) return; return H.exportGroup(gid); }
  if (o === 'newRecovery') return H.newRecovery();
  if (o === 'delParishDo') return H.delParishDo(b);
  for (const fn of [H.doRecord, H.doAction, H.doMember, H.doGroup, H.doParish, H.doMsg, H.doNews, H.doIssue]) { if (await fn(o, b) !== false) return; }
});
document.addEventListener('change', (e) => {
  const t = e.target;
  if (t.id === 'f-type') { const w = $('f-custom-wrap'); if (w) w.hidden = t.value !== 'ina'; return; }
  if (t.id === 'f-sy') return H.onSyChange();
  if (t.id === 'scan-f') return H.onScanFile(t.files && t.files[0], t.getAttribute('data-mode'));
  if (t.id === 'docgroup') { S.docGroup = t.value; return H.refreshDocs(); }
  if (t.hasAttribute && t.hasAttribute('data-gift') && t.type === 'checkbox') return H.toggleGift(t.getAttribute('data-gift'), t.checked);
});
document.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && e.target.id === 'chat-in') { e.preventDefault(); H.sendChat(); } });

// ---------- štart ----------
function waitFor(cond, ms) { return new Promise((res) => { const t0 = Date.now(); (function w() { if (cond() || Date.now() - t0 > ms) res(); else setTimeout(w, 80); })(); }); }
async function onLink(url) { await waitFor(() => S.uid && (!S.pid || S.me !== undefined), 6000); H.handleLink(url); }
async function boot() {
  render();
  if (configMissing) return;
  try { const u = await signIn(); S.uid = u.uid; } catch (e) { console.error(e); S.err = 'Nepodarilo sa pripojiť. Skontroluj internet a otvor aplikáciu znova.'; render(); return; }
  if (S.pid) startParish(S.pid); else render();
  if (Capacitor.isNativePlatform()) {
    try { const l = await CapApp.getLaunchUrl(); if (l && l.url) onLink(l.url); } catch (e) {}
    CapApp.addListener('appUrlOpen', (ev) => onLink(ev.url));
    CapApp.addListener('backButton', () => {
      if (!ov.hidden) return closeSheet();
      if (S.tab === 'chat' && S.chatGid && isOwner()) { closeChat(); return render(); }
      const d = V.defaultTab(); if (S.tab && S.tab !== d) return setTab(d);
      CapApp.exitApp();
    });
  } else if (location.search.indexOf('p=') >= 0) onLink(location.href);
}
boot();
window.__ib = { S };
