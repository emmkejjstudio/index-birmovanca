// Spodné okná (formuláre a potvrdenia) a ich obsluha.
import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';
import QRCode from 'qrcode';
import { S, startParish, stopAll, planOf, isOwner, isAnimator, groupName, openChat, closeChat, requestRender, myGroup } from './store.js';
import * as A from './actions.js';
import { openSheet, closeSheet, notice, setErr, onClose } from './ui.js';
import { startScan, stopScan, scanFromFile, parseLink } from './scan.js';
import { pdfGroupReport, pdfCandidateIndex, pdfQrSheet } from './pdf.js';
import { STYPES, GIFTS, svcName } from './views.js';
import { FEAST_CATALOG, FEAST_PRESETS, PRESET_LABELS, feastsOfYear } from './calendar.js';
import { $, pstore, esc, iso, todayISO, parts, weekday, longDate, fmtAt, fmtCode, normCode, validFullName, clean, MONTHS, pad2 } from './util.js';
import { LANDING_URL, PLAY_URL, SUPPORT_URL, SUPPORT_IN_ANDROID_APP, APP_VERSION, AUTHOR_NAME, AUTHOR_EMAIL } from './firebase-config.js';

const val = (id) => ($(id) ? $(id).value : '');
const btns = (...b) => '<div class="btns">' + b.join('') + '</div>';
const closeBtn = (t) => '<button class="btn plain" data-do="close">' + (t || 'Zavrieť') + '</button>';
const errBox = '<div class="err" id="f-err"></div>';
const fail = (e) => { console.error(e); setErr('Nepodarilo sa. Skontroluj internet a skús znova.'); };
const lockBtn = (b, on) => { if (b) b.disabled = on; };

// ---------- odkazy a QR ----------
export const joinLink = () => LANDING_URL + '?p=' + S.pid;
export const massLink = () => LANDING_URL + '?p=' + S.pid + '&m=1';
export const inviteLink = (t) => LANDING_URL + '?p=' + S.pid + '&i=' + t;

export async function sheetQR(kind, token) {
  const url = kind === 'join' ? joinLink() : kind === 'mass' ? massLink() : inviteLink(token);
  const title = kind === 'join' ? 'QR kód pre birmovancov' : kind === 'mass' ? 'QR kód do sakristie' : 'Pozvánka pre animátora';
  const hint = kind === 'join' ? 'Birmovanci ho naskenujú fotoaparátom. Otvorí sa stránka, odkiaľ si nainštalujú aplikáciu, a v aplikácii sa pripoja do skupiny.' : kind === 'mass' ? 'Vytlač ho a daj do sakristie. Birmovanec ním po omši zapíše svoju účasť (aplikácia zapíše dátum a čas).' : 'Pozvánka platí na jedno použitie. Pošli ju animátorovi (napr. cez SMS alebo Messenger).';
  const png = await QRCode.toDataURL(url, { errorCorrectionLevel: 'M', margin: 2, width: 520 });
  openSheet('<h3>' + title + '</h3><img class="qrimg" alt="QR kód" src="' + png + '">'
    + (kind !== 'mass' ? '<div class="lab">Kód farnosti</div><div class="code">' + fmtCode(S.pid) + '</div>' : '') + '<p class="hint">' + hint + '</p>'
    + btns('<button class="btn" data-do="qrpdf" data-k="' + kind + '" data-t="' + esc(token || '') + '">Hárok na tlač (PDF)</button>', '<button class="btn ghost" data-do="qrshare" data-k="' + kind + '" data-t="' + esc(token || '') + '">Poslať odkaz</button>', closeBtn()));
}
export async function qrPdfPublic(kind, token) {
  const url = kind === 'join' ? joinLink() : kind === 'mass' ? massLink() : inviteLink(token);
  const o = kind === 'mass'
    ? { title: 'INDEX BIRMOVANCA', subtitle: S.parish.name, heading: 'Zapíš si účasť na svätej omši', steps: ['Otvor aplikáciu Index birmovanca', 'Ťukni na Skenovať QR kód', 'Namier fotoaparát na tento kód'], filename: 'qr-sakristia.pdf' }
    : kind === 'join'
      ? { title: 'INDEX BIRMOVANCA', subtitle: S.parish.name, heading: 'Pripoj sa do skupiny', steps: ['Naskenuj kód fotoaparátom a nainštaluj aplikáciu', 'V aplikácii ťukni Som birmovanec', 'Vyber svoju skupinu a napíš meno a priezvisko'], filename: 'qr-pripojenie.pdf', code: fmtCode(S.pid) }
      : { title: 'POZVÁNKA PRE ANIMÁTORA', subtitle: S.parish.name, heading: 'Pripoj sa ako animátor', steps: ['Nainštaluj aplikáciu Index birmovanca', 'Ťukni Som animátor', 'Naskenuj tento kód (platí na jedno použitie)'], filename: 'pozvanka-animator.pdf', code: fmtCode(S.pid) };
  await pdfQrSheet({ ...o, url });
}
export async function shareLinkPublic(kind, token) {
  const url = kind === 'join' ? joinLink() : kind === 'mass' ? massLink() : inviteLink(token);
  const text = (kind === 'invite' ? 'Pozvánka pre animátora: ' : 'Pripoj sa do skupiny v aplikácii Index birmovanca: ') + url;
  if (Capacitor.isNativePlatform()) { await Share.share({ text, dialogTitle: 'Poslať odkaz' }); return; }
  try { await navigator.clipboard.writeText(text); notice('Odkaz skopírovaný', 'Môžeš ho vložiť do správy.'); } catch (e) { notice('Odkaz', url); }
}

// ---------- pripojenie birmovanca / animátora ----------
export function sheetJoinStart(mode, prefill) {
  const anim = mode === 'anim';
  openSheet('<h3>' + (anim ? 'Pozvánka animátora' : 'Pripojiť sa do skupiny') + '</h3><p class="hint">' + (anim ? 'Naskenuj QR kód pozvánky, ktorú ti poslal správca skupiny.' : 'Naskenuj QR kód farnosti od správcu skupiny alebo napíš kód farnosti.') + '</p>'
    + '<button class="btn wide" data-do="scanStart" data-mode="' + mode + '">Skenovať QR kód</button>'
    + (anim ? '' : '<div class="field"><label for="f-code">Kód farnosti</label><input id="f-code" autocomplete="off" autocapitalize="characters" placeholder="napr. K7QM-3XTD" value="' + esc(prefill || '') + '"></div>' + errBox
      + btns('<button class="btn" data-do="codeNext">Pokračovať</button>', closeBtn('Zrušiť'))) + (anim ? errBox + btns(closeBtn('Zrušiť')) : ''));
}
export function sheetScanGeneric(mode) {
  openSheet('<h3>Skenovať QR kód</h3><p class="hint">Namier fotoaparát na kód. Načíta sa sám.</p><div class="scanbox"><video id="scan-v" playsinline muted autoplay></video><i></i></div>' + errBox
    + btns('<label class="btn ghost" for="scan-f">Vybrať fotku kódu</label><input type="file" id="scan-f" accept="image/*" hidden data-mode="' + mode + '">', closeBtn()));
  onClose(stopScan);
  startScan($('scan-v'), (t) => handleScanText(mode, t), (m) => setErr(m));
}
async function handleScanText(mode, text) {
  const link = parseLink(text);
  if (!link) { setErr('Toto nie je kód z aplikácie Index birmovanca.'); return true; }
  if (mode === 'mass') { stopScan(); await applyMassQR(link); return false; }
  if (mode === 'anim' || link.i) { if (!link.i) { setErr('Toto je kód farnosti, nie pozvánka animátora.'); return true; } stopScan(); await goAnimator(link.p, link.i); return false; }
  stopScan(); await goJoin(link.p); return false;
}
export async function onScanFile(file, mode) {
  const t = await scanFromFile(file);
  if (!t) return setErr('Na fotke sa nenašiel QR kód. Skús ju odfotiť bližšie a ostrejšie.');
  await handleScanText(mode, t);
}
export async function goJoin(pid) {
  try {
    const p = await A.fetchParish(pid);
    if (!p) return sheetJoinStart('join', fmtCode(pid)), setErr('Farnosť s týmto kódom sa nenašla.');
    const groups = await A.fetchGroups(pid);
    if (!groups.length) return notice('Farnosť ' + p.name, 'Správca skupiny zatiaľ nevytvoril žiadnu skupinu. Skús to neskôr.');
    openSheet('<h3>' + esc(p.name) + '</h3><p class="hint">Vyber svoju skupinu a napíš meno a priezvisko. Žiadosť dostane správca skupiny a potvrdí ťa.</p>'
      + '<div class="sel">' + groups.map((g, i) => '<label><input type="radio" name="grp" value="' + g.id + '"' + (groups.length === 1 || i === 0 && false ? ' checked' : '') + '><span>' + esc(g.name) + '</span></label>').join('') + '</div>'
      + '<div class="field"><label for="f-name">Meno a priezvisko</label><input id="f-name" autocomplete="name" maxlength="60" placeholder="napr. Jana Nováková"></div>' + errBox
      + '<p class="hint">Ukladá sa len meno a priezvisko. Žiadne iné osobné údaje.</p>'
      + btns('<button class="btn" data-do="joinSend" data-p="' + pid + '">Odoslať žiadosť</button>', closeBtn('Zrušiť')));
  } catch (e) { sheetJoinStart('join', fmtCode(pid)); fail(e); }
}
export async function goAnimator(pid, token) {
  try {
    const p = await A.fetchParish(pid), inv = await A.fetchInvite(pid, token);
    if (!p || !inv) return notice('Pozvánka neplatí', 'Pozvánka už bola použitá alebo ju správca skupiny zrušil. Popros ho o novú.');
    const groups = await A.fetchGroups(pid), g = groups.find((x) => x.id === inv.gid);
    if (!g) return notice('Pozvánka neplatí', 'Skupina už neexistuje.');
    openSheet('<h3>Animátor: ' + esc(g.name) + '</h3><p class="hint">Farnosť ' + esc(p.name) + '. Napíš meno a priezvisko a pripojíš sa ako animátor tejto skupiny.</p>'
      + '<div class="field"><label for="f-name">Meno a priezvisko</label><input id="f-name" autocomplete="name" maxlength="60"></div>' + errBox
      + btns('<button class="btn" data-do="animSend" data-p="' + pid + '" data-t="' + esc(token) + '" data-g="' + inv.gid + '">Pripojiť sa</button>', closeBtn('Zrušiť')));
  } catch (e) { notice('Chyba', 'Nepodarilo sa načítať pozvánku. Skontroluj internet.'); }
}
async function applyMassQR(link) {
  const d = todayISO();
  if (link.p !== S.pid) return notice('Kód nezapísaný', 'Tento kód patrí inej farnosti.');
  if (!link.m) return notice('Kód nezapísaný', 'Toto nie je kód zo sakristie.');
  if (!planOf(S.parish).plan.some((p) => p.date === d)) return notice('Nič sa nezapísalo', 'Dnes (' + longDate(d) + ') nie je v indexe zapísaná svätá omša.');
  const ex = S.records['m_' + d];
  if (ex && ex.confirmed) return notice('Už potvrdené', 'Táto omša je už potvrdená správcom skupiny.');
  try {
    await A.saveRecord('m_' + d, { kind: 'mass', date: d, place: S.parish.name, via: 'qr' });
    openSheet('<p class="bigok">Účasť zapísaná</p><dl class="kv"><dt>Omša</dt><dd>' + weekday(d) + ' ' + longDate(d) + '</dd><dt>Čas</dt><dd>' + fmtAt(new Date().toISOString()) + '</dd></dl><p class="hint">Záznam čaká na potvrdenie správcom skupiny.</p>' + btns('<button class="btn" data-do="close">Hotovo</button>'));
  } catch (e) { notice('Nepodarilo sa', 'Záznam sa nepodarilo uložiť. Skontroluj internet.'); }
}
export async function handleLink(text) {
  const link = parseLink(text); if (!link) return;
  if (link.m && S.me && S.pid === link.p && S.me.role === 'candidate' && S.me.status !== 'pending') return applyMassQR(link);
  if (S.me) return; // už je vo farnosti
  if (link.i) return goAnimator(link.p, link.i);
  return goJoin(link.p);
}

// ---------- založenie farnosti ----------
const syNow = () => { const d = new Date(); return d.getMonth() >= 6 ? d.getFullYear() : d.getFullYear() - 1; };
const dflt = (sy) => ({ from: iso(sy, 10, 1), to: iso(sy + 1, 5, 31), confFrom: sy + '-11', confTo: (sy + 1) + '-05' });
export function sheetSetup() {
  const sy = syNow(), d = dflt(sy);
  openSheet('<h3>Založiť farnosť</h3><p class="hint">Po založení si vytvoríš skupiny a pošleš birmovancom QR kód.</p>'
    + '<div class="field"><label for="f-pn">Názov farnosti</label><input id="f-pn" maxlength="100" placeholder="napr. Farnosť Všetkých svätých, Humenné"></div>'
    + '<div class="field"><label for="f-name">Tvoje meno a priezvisko</label><input id="f-name" maxlength="60" autocomplete="name"></div>'
    + '<div class="field"><label for="f-ot">Tvoja funkcia (napíš sám)</label><input id="f-ot" maxlength="40" placeholder="napr. kaplan, farár, katechétka, animátor"></div>'
    + '<div class="field"><label for="f-preset">Zoznam prikázaných sviatkov</label><select id="f-preset"><option value="SK">' + PRESET_LABELS.SK + '</option><option value="GENERAL">' + PRESET_LABELS.GENERAL + '</option></select></div>'
    + '<div class="field"><label for="f-sy">Začiatok školského roka</label><input id="f-sy" type="number" min="2020" max="2100" value="' + sy + '"></div>'
    + '<div class="field"><label for="f-from">Omše od</label><input id="f-from" type="date" value="' + d.from + '"></div><div class="field"><label for="f-to">Omše do</label><input id="f-to" type="date" value="' + d.to + '"></div>'
    + '<div class="field"><label for="f-cf">Spoveď od (mesiac)</label><input id="f-cf" type="month" value="' + d.confFrom + '"></div><div class="field"><label for="f-ct">Spoveď do (mesiac)</label><input id="f-ct" type="month" value="' + d.confTo + '"></div>'
    + '<p class="hint">Dátumy a sviatky môžeš neskôr zmeniť v záložke Farnosť.</p>' + errBox
    + btns('<button class="btn" data-do="setupDo">Založiť farnosť</button>', closeBtn('Zrušiť')));
}
export function onSyChange() {
  const sy = parseInt(val('f-sy'), 10); if (!sy) return;
  const d = dflt(sy); $('f-from').value = d.from; $('f-to').value = d.to; $('f-cf').value = d.confFrom; $('f-ct').value = d.confTo;
}
async function setupDo(b) {
  const name = clean(val('f-pn')), owner = validFullName(val('f-name')), from = val('f-from'), to = val('f-to'), cf = val('f-cf'), ct = val('f-ct'), preset = val('f-preset');
  if (name.length < 2) return setErr('Napíš názov farnosti.');
  if (!owner) return setErr('Napíš svoje meno a priezvisko.');
  const ownerTitle = clean(val('f-ot'));
  if (ownerTitle.length < 2) return setErr('Napíš svoju funkciu, napríklad kaplan, farár alebo katechétka.');
  if (!from || !to || from > to) return setErr('Skontroluj dátumy omší.');
  if (!cf || !ct || cf > ct) return setErr('Skontroluj mesiace spovede.');
  lockBtn(b, true);
  try {
    await A.createParish({ name, ownerTitle, ownerName: owner, country: preset === 'SK' ? 'SK' : 'INE', schoolYear: parseInt(val('f-sy'), 10) || syNow(), from, to, confFrom: cf, confTo: ct, feasts: FEAST_PRESETS[preset].slice(), preset });
    const codes = await A.listSecrets();
    openSheet('<h3>Farnosť je založená</h3><div class="lab">Kód farnosti</div><div class="code">' + fmtCode(S.pid) + '</div><div class="lab">Kód obnovy správcu skupiny</div><div class="code">' + esc(codes[0] || '') + '</div>'
      + '<div class="warnbox">Kód obnovy si zapíš na bezpečné miesto. Ak vymeníš telefón alebo vymažeš údaje aplikácie, bez neho o farnosť prídeš. Nájdeš ho aj v záložke Farnosť.</div>'
      + btns('<button class="btn" data-do="close">Rozumiem, pokračovať</button>'));
  } catch (e) { lockBtn(b, false); fail(e); }
}
export function sheetRestore() {
  openSheet('<h3>Obnoviť farnosť</h3><p class="hint">Na novom telefóne zadaj kód farnosti a kód obnovy správcu skupiny.</p>'
    + '<div class="field"><label for="f-code">Kód farnosti</label><input id="f-code" autocapitalize="characters" autocomplete="off"></div>'
    + '<div class="field"><label for="f-rec">Kód obnovy</label><input id="f-rec" autocapitalize="characters" autocomplete="off"></div>'
    + '<div class="field"><label for="f-name">Tvoje meno a priezvisko</label><input id="f-name" maxlength="60"></div>' + errBox
    + btns('<button class="btn" data-do="restoreDo">Obnoviť</button>', closeBtn('Zrušiť')));
}

// ---------- obsluha tlačidiel z uvodných okien ----------
export async function doAction(o, b) {
  if (o === 'scanStart') return sheetScanGeneric(b.getAttribute('data-mode'));
  if (o === 'codeNext') { const c = normCode(val('f-code')); if (c.length < 6) return setErr('Zadaj kód farnosti.'); return goJoin(c); }
  if (o === 'joinSend') {
    const gid = (document.querySelector('input[name=grp]:checked') || {}).value, nm = validFullName(val('f-name'));
    if (!gid) return setErr('Vyber skupinu.'); if (!nm) return setErr('Napíš meno a priezvisko.');
    lockBtn(b, true); try { await A.joinCandidate(b.getAttribute('data-p'), gid, nm); closeSheet(); } catch (e) { lockBtn(b, false); fail(e); } return;
  }
  if (o === 'animSend') {
    const nm = validFullName(val('f-name')); if (!nm) return setErr('Napíš meno a priezvisko.');
    lockBtn(b, true); try { await A.joinAnimator(b.getAttribute('data-p'), b.getAttribute('data-t'), b.getAttribute('data-g'), nm); closeSheet(); } catch (e) { lockBtn(b, false); fail(e); } return;
  }
  if (o === 'setupDo') return setupDo(b);
  if (o === 'restoreDo') {
    const pid = normCode(val('f-code')), rec = normCode(val('f-rec')), nm = validFullName(val('f-name'));
    if (pid.length < 6 || rec.length < 6) return setErr('Zadaj oba kódy.'); if (!nm) return setErr('Napíš meno a priezvisko.');
    lockBtn(b, true); try { await A.restoreOwner(pid, rec, nm); closeSheet(); } catch (e) { lockBtn(b, false); setErr('Kódy nesedia alebo nie je internet.'); } return;
  }
  return false;
}

// ---------- index birmovanca: omša, služba, spoveď ----------
const placeField = (id, v) => '<div class="field"><label for="' + id + '">Miesto (farnosť, kostol)</label><input id="' + id + '" value="' + esc(v) + '" autocomplete="off"></div>';
const lastPlace = () => { const k = Object.keys(S.records).map((x) => S.records[x].place).filter(Boolean); return k.length ? k[k.length - 1] : S.parish.name; };
function sheetConfirmed(title, rows, rec) {
  let h = '<h3>' + esc(title) + '</h3><dl class="kv">';
  rows.forEach((r) => { if (r[1]) h += '<dt>' + r[0] + '</dt><dd>' + esc(r[1]) + '</dd>'; });
  h += '<dt>Potvrdil</dt><dd>' + esc(rec.confirmed.by) + '</dd><dt>Kedy</dt><dd>' + fmtAt(rec.confirmed.at) + '</dd></dl><p class="hint">Potvrdený záznam sa už nedá upraviť.</p>' + btns(closeBtn());
  openSheet(h);
}
export function sheetMass(d) {
  const r = S.records['m_' + d], plan = planOf(S.parish).plan.find((p) => p.date === d);
  if (r && r.confirmed) return sheetConfirmed(weekday(d) + ' ' + longDate(d), [['Miesto', r.place], ['Zapísané', fmtAt(r.at)]], r);
  openSheet('<h3>' + weekday(d) + ' ' + longDate(d) + '</h3>' + (plan && plan.name ? '<p class="hint">' + esc(plan.name) + '</p>' : '') + placeField('f-place', r ? r.place : lastPlace()) + errBox
    + btns('<button class="btn" data-do="savemass" data-d="' + d + '">Bol som na omši</button>', r ? '<button class="btn danger" data-do="delrec" data-id="m_' + d + '">Zrušiť záznam</button>' : '', closeBtn()));
}
export function sheetSvc(id) {
  const s = id ? S.records[id] : null;
  if (s && s.confirmed) return sheetConfirmed(svcName(s) + ' · ' + longDate(s.date), [['Miesto / poznámka', s.place]], s);
  const opts = Object.keys(STYPES).map((k) => '<option value="' + k + '"' + (s && s.type === k ? ' selected' : '') + '>' + STYPES[k] + '</option>').join('');
  openSheet('<h3>' + (s ? 'Upraviť službu' : 'Nová služba') + '</h3><div class="field"><label for="f-type">Druh</label><select id="f-type">' + opts + '</select></div>'
    + '<div class="field" id="f-custom-wrap"' + (s && s.type === 'ina' ? '' : ' hidden') + '><label for="f-custom">Aká služba alebo aktivita</label><input id="f-custom" maxlength="80" autocomplete="off" value="' + esc((s && s.custom) || '') + '" placeholder="napr. spev v schole, brigáda pri fare"></div>'
    + '<div class="field"><label for="f-date">Dátum</label><input type="date" id="f-date" max="' + todayISO() + '" value="' + (s ? s.date : todayISO()) + '"></div>' + placeField('f-place', s ? s.place : lastPlace()) + errBox
    + btns('<button class="btn" data-do="savesvc" data-id="' + (id || '') + '">Uložiť</button>', s ? '<button class="btn danger" data-do="delrec" data-id="' + id + '">Zmazať</button>' : '', closeBtn()));
}
export function sheetConf(k) {
  const r = S.records['c_' + k], y = +k.slice(0, 4), m = +k.slice(5, 7);
  if (r && r.confirmed) return sheetConfirmed('Sviatosť zmierenia · ' + MONTHS[m - 1].toLowerCase(), [['Dátum', longDate(r.date)], ['Miesto', r.place]], r);
  const t = todayISO(), min = iso(y, m, 1), last = new Date(y, m, 0).getDate(); let max = iso(y, m, last); if (max > t) max = t;
  const def = r ? r.date : (t >= min && t <= iso(y, m, last) ? t : max);
  openSheet('<h3>Sviatosť zmierenia · ' + MONTHS[m - 1].toLowerCase() + '</h3><div class="field"><label for="f-date">Dátum</label><input type="date" id="f-date" min="' + min + '" max="' + max + '" value="' + def + '"></div>' + placeField('f-place', r ? r.place : lastPlace()) + errBox
    + btns('<button class="btn" data-do="saveconf" data-k="' + k + '">Uložiť</button>', r ? '<button class="btn danger" data-do="delrec" data-id="c_' + k + '">Zrušiť záznam</button>' : '', closeBtn()));
}
export async function doRecord(o, b) {
  const place = () => { const v = clean(val('f-place')); if (!v) { setErr('Zadaj miesto.'); return null; } return v; };
  try {
    if (o === 'savemass') { const p = place(); if (!p) return true; const d = b.getAttribute('data-d'); await A.saveRecord('m_' + d, { kind: 'mass', date: d, place: p, via: 'manual' }); closeSheet(); return true; }
    if (o === 'delrec') { await A.deleteRecord(b.getAttribute('data-id')); closeSheet(); return true; }
    if (o === 'savesvc') {
      const p = place(); if (!p) return true; const dt = val('f-date'), type = val('f-type'), cu = type === 'ina' ? clean(val('f-custom')) : '';
      if (!dt || dt > todayISO()) { setErr('Vyber dátum, ktorý už nastal.'); return true; }
      if (type === 'ina' && !cu) { setErr('Napíš, o akú službu alebo aktivitu ide.'); return true; }
      const id = b.getAttribute('data-id') || 's_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
      await A.saveRecord(id, { kind: 'service', type, custom: cu, date: dt, place: p, via: 'manual' }); closeSheet(); return true;
    }
    if (o === 'saveconf') {
      const p = place(); if (!p) return true; const cd = val('f-date'), k = b.getAttribute('data-k');
      if (!cd || cd < $('f-date').min || cd > $('f-date').max) { setErr('Vyber dátum v tomto mesiaci, ktorý už nastal.'); return true; }
      await A.saveRecord('c_' + k, { kind: 'conf', date: cd, place: p, via: 'manual' }); closeSheet(); return true;
    }
  } catch (e) { fail(e); return true; }
  return false;
}
export async function toggleGift(i, on) { try { if (on) await A.saveRecord('g_' + i, { kind: 'gift', date: todayISO() }); else await A.deleteRecord('g_' + i); } catch (e) { notice('Nepodarilo sa', 'Zmenu sa nepodarilo uložiť. Skontroluj internet.'); } }

// ---------- meno, odchod ----------
export function sheetName() {
  openSheet('<h3>Zmeniť meno</h3><div class="field"><label for="f-name">Meno a priezvisko</label><input id="f-name" maxlength="60" value="' + esc(S.me.name) + '"></div>' + errBox + btns('<button class="btn" data-do="savename">Uložiť</button>', closeBtn()));
}
export function sheetLeave() {
  const pend = S.me.status === 'pending';
  openSheet('<h3>' + (pend ? 'Zrušiť žiadosť?' : 'Zmazať moje údaje?') + '</h3><p class="hint">' + (pend ? 'Tvoja žiadosť sa zruší.' : 'Natrvalo sa zmažú všetky tvoje záznamy a členstvo vo farnosti. Túto akciu nemožno vrátiť.') + '</p>' + btns('<button class="btn danger" data-do="leaveDo">' + (pend ? 'Zrušiť žiadosť' : 'Áno, zmazať') + '</button>', closeBtn('Nie')));
}
export async function leaveDo() {
  try { await A.deleteMyData(); pstore.removeItem('ib_pid'); stopAll(); S.pid = ''; S.tab = ''; closeSheet(); requestRender(); } catch (e) { fail(e); }
}

// ---------- správca skupiny/animátor: člen ----------
export async function sheetMember(mid) {
  const m = S.members.find((x) => x.id === mid); if (!m) return;
  const owner = isOwner();
  const g = S.groups.find((x) => x.id === m.groupId), canConf = owner || (isAnimator() && g && g.animConfirm);
  openSheet('<h3>' + esc(m.name) + '</h3><p class="hint">Načítavam…</p>');
  let recs = {}; try { recs = m.status === 'pending' || m.role !== 'candidate' ? {} : await A.getRecords(mid); } catch (e) {}
  const { plan, months } = planOf(S.parish);
  let h = '<h3>' + esc(m.name) + '</h3><dl class="kv"><dt>Skupina</dt><dd>' + esc(groupName(m.groupId)) + '</dd><dt>Rola</dt><dd>' + (m.role === 'animator' ? 'animátor' : 'birmovanec') + '</dd><dt>Stav</dt><dd>' + (m.status === 'pending' ? 'čaká na potvrdenie' : m.status === 'muted' ? 'stlmený v chate' : 'aktívny') + '</dd></dl>';
  const pend = [];
  if (m.role === 'candidate' && m.status !== 'pending') {
    const lab = (id) => id[0] === 'm' ? 'Omša ' + longDate(id.slice(2)) : id[0] === 'c' ? 'Spoveď ' + MONTHS[+id.slice(7, 9) - 1].toLowerCase() + ' ' + id.slice(2, 6) : id[0] === 's' ? svcName(recs[id]) + ' ' + longDate(recs[id].date) : '';
    Object.keys(recs).filter((k) => k[0] !== 'g' && !recs[k].confirmed).sort().forEach((k) => pend.push(k));
    const nm = Object.keys(recs).filter((k) => k[0] === 'm').length, nc = Object.keys(recs).filter((k) => k[0] === 'c').length, ns = Object.keys(recs).filter((k) => k[0] === 's').length, ng = Object.keys(recs).filter((k) => k[0] === 'g').length;
    h += '<p class="hint">Omše ' + nm + '/' + plan.length + ' · spoveď ' + nc + '/' + months.length + ' · služby ' + ns + ' · dary ' + ng + '/7</p>';
    if (pend.length) {
      h += '<div class="lab">Čaká na potvrdenie (' + pend.length + ')</div><div class="sel">' + pend.map((k) => '<label><input type="checkbox" data-sel="' + k + '" ' + (canConf ? 'checked' : 'disabled') + '><span>' + esc(lab(k)) + '</span></label>').join('') + '</div>';
      if (canConf) h += btns('<button class="btn" data-do="confRecs" data-m="' + mid + '">Potvrdiť vybrané</button>');
    } else h += '<p class="hint">Všetky záznamy sú potvrdené.</p>';
  }
  h += errBox + '<div class="btns">';
  if (m.status === 'pending') {
    if (canConf) h += '<button class="btn" data-do="memConfirm" data-m="' + mid + '">Potvrdiť pripojenie</button>';
    if (owner) h += '<button class="btn danger" data-do="memRemove" data-m="' + mid + '">Zamietnuť</button>';
  } else if (owner) {
    h += '<button class="btn ghost" data-do="memMute" data-m="' + mid + '">' + (m.status === 'muted' ? 'Zrušiť stlmenie v chate' : 'Stlmiť v chate') + '</button>';
    h += '<button class="btn ghost" data-do="memRole" data-m="' + mid + '">' + (m.role === 'animator' ? 'Urobiť birmovancom' : 'Urobiť animátorom') + '</button>';
    if (S.groups.length > 1) h += '<button class="btn ghost" data-do="memMove" data-m="' + mid + '">Presunúť do inej skupiny</button>';
    h += '<button class="btn danger" data-do="memRemove" data-m="' + mid + '">Odstrániť zo skupiny</button>';
  } else if (isAnimator()) h += '<button class="btn ghost" data-do="propose" data-m="' + mid + '">Navrhnúť správcovi skupiny…</button>';
  if (m.role === 'candidate' && m.status !== 'pending') h += '<button class="btn ghost" data-do="memPdf" data-m="' + mid + '">Index do PDF</button>';
  openSheet(h + closeBtn() + '</div>');
}
export async function doMember(o, b) {
  const mid = b.getAttribute('data-m'), m = S.members.find((x) => x.id === mid);
  try {
    if (o === 'memConfirm') { await A.confirmMember(mid); return sheetMember(mid), true; }
    if (o === 'memMute') { await A.setMember(mid, { status: m.status === 'muted' ? 'active' : 'muted' }); closeSheet(); return true; }
    if (o === 'memRole') { await A.setMember(mid, { role: m.role === 'animator' ? 'candidate' : 'animator' }); closeSheet(); return true; }
    if (o === 'memMove') {
      openSheet('<h3>Presunúť: ' + esc(m.name) + '</h3><div class="sel">' + S.groups.filter((g) => g.id !== m.groupId).map((g) => '<label><input type="radio" name="grp" value="' + g.id + '"><span>' + esc(g.name) + '</span></label>').join('') + '</div>' + errBox + btns('<button class="btn" data-do="memMoveDo" data-m="' + mid + '">Presunúť</button>', closeBtn('Zrušiť'))); return true;
    }
    if (o === 'memMoveDo') { const gid = (document.querySelector('input[name=grp]:checked') || {}).value; if (!gid) { setErr('Vyber skupinu.'); return true; } await A.setMember(mid, { groupId: gid }); closeSheet(); return true; }
    if (o === 'memRemove') {
      openSheet('<h3>Odstrániť: ' + esc(m.name) + '?</h3><p class="hint">Zmažú sa všetky jeho záznamy a členstvo. Túto akciu nemožno vrátiť.</p>' + btns('<button class="btn danger" data-do="memRemoveDo" data-m="' + mid + '">Áno, odstrániť</button>', closeBtn('Nie'))); return true;
    }
    if (o === 'memRemoveDo') { await A.removeMember(mid); closeSheet(); return true; }
    if (o === 'confRecs') {
      const ids = [].slice.call(document.querySelectorAll('[data-sel]')).filter((i) => i.checked).map((i) => i.getAttribute('data-sel'));
      if (!ids.length) { setErr('Vyber aspoň jeden záznam.'); return true; }
      await A.confirmRecords(mid, ids); return sheetMember(mid), true;
    }
    if (o === 'memPdf') return exportMember(mid), true;
    if (o === 'propose') return sheetPropose(mid), true;
  } catch (e) { fail(e); return true; }
  return false;
}
export function sheetPropose(mid) {
  const m = mid ? S.members.find((x) => x.id === mid) : null;
  openSheet('<h3>Návrh pre správcu skupiny</h3><p class="hint">Rozhodnutie urobí správca skupiny. Animátor nemôže nikoho odstrániť ani zmazať skupinu.</p>'
    + '<div class="field"><label for="f-act">Čo navrhuješ</label><select id="f-act">' + (m ? '<option value="remove_member">Odstrániť ' + esc(m.name) + ' zo skupiny</option><option value="mute">Stlmiť ' + esc(m.name) + ' v chate</option>' : '') + '<option value="delete_group">Zmazať skupinu</option></select></div>'
    + '<div class="field"><label for="f-note">Poznámka (nepovinná)</label><textarea id="f-note" maxlength="300"></textarea></div>' + errBox
    + btns('<button class="btn" data-do="proposeDo" data-m="' + (mid || '') + '">Poslať správcovi skupiny</button>', closeBtn('Zrušiť')));
}
export async function proposeDo(b) {
  const mid = b.getAttribute('data-m'), m = mid ? S.members.find((x) => x.id === mid) : null, action = val('f-act');
  try {
    await A.addIssue({ type: 'proposal', gid: S.me.groupId, action, targetUid: action === 'delete_group' ? '' : mid, targetName: action === 'delete_group' ? '' : (m ? m.name : ''), note: clean(val('f-note')) });
    notice('Odoslané', 'Návrh dostal správca skupiny a rozhodne o ňom.');
  } catch (e) { fail(e); }
}

// ---------- skupiny ----------
export function sheetAddGroup() {
  openSheet('<h3>Nová skupina</h3><div class="field"><label for="f-gn">Názov skupiny</label><input id="f-gn" maxlength="60" placeholder="napr. Birmovanci 2026/27 – A"></div>'
    + '<label class="toggle"><input type="checkbox" id="f-ac"><span>Animátor môže potvrdzovať birmovancov (pripojenie a záznamy v indexe)</span></label>'
    + '<label class="toggle"><input type="checkbox" id="f-ad"><span>Animátor môže nahrávať dokumenty do skupiny</span></label>' + errBox + btns('<button class="btn" data-do="addGroupDo">Vytvoriť</button>', closeBtn('Zrušiť')));
}
export function sheetGroup(gid) {
  const g = S.groups.find((x) => x.id === gid); if (!g) return;
  const anims = S.members.filter((m) => m.groupId === gid && m.role === 'animator');
  openSheet('<h3>' + esc(g.name) + '</h3><div class="field"><label for="f-gn">Názov skupiny</label><input id="f-gn" maxlength="60" value="' + esc(g.name) + '"></div>'
    + '<label class="toggle"><input type="checkbox" id="f-ac"' + (g.animConfirm ? ' checked' : '') + '><span>Animátor môže potvrdzovať birmovancov (pripojenie a záznamy v indexe)</span></label>'
    + '<label class="toggle"><input type="checkbox" id="f-ad"' + (g.animDocs ? ' checked' : '') + '><span>Animátor môže nahrávať dokumenty do skupiny</span></label>' + errBox
    + btns('<button class="btn" data-do="saveGroup" data-g="' + gid + '">Uložiť</button>')
    + '<div class="lab">Animátori (' + anims.length + ')</div><div class="list">' + anims.map((a) => '<button class="row noicon" data-do="openMember" data-m="' + a.id + '"><span class="info"><span class="t">' + esc(a.name) + '</span></span><span class="chip none">Spravovať</span></button>').join('') + '</div>'
    + btns('<button class="btn ghost" data-do="inviteAnim" data-g="' + gid + '">Pozvať animátora</button>')
    + btns('<button class="btn danger" data-do="delGroup" data-g="' + gid + '">Zmazať skupinu</button>', closeBtn()));
}
export function sheetDeleteGroup(gid, issueId) {
  const g = S.groups.find((x) => x.id === gid); if (!g) return;
  openSheet('<h3>Zmazať skupinu?</h3><p class="hint">Skupina <b>' + esc(g.name) + '</b> sa zmaže spolu so všetkými birmovancami, ich záznamami, chatom, oznamami a dokumentami. Túto akciu nemožno vrátiť. Skupinu maž až po skončení prípravy. Predtým si môžeš stiahnuť prehľad do PDF.</p>'
    + btns('<button class="btn ghost" data-do="exportGroupG" data-g="' + gid + '">Stiahnuť prehľad do PDF</button>')
    + '<div class="field"><label for="f-conf">Pre potvrdenie napíš názov skupiny</label><input id="f-conf" autocomplete="off"></div>' + errBox
    + btns('<button class="btn danger" data-do="delGroupDo" data-g="' + gid + '" data-i="' + (issueId || '') + '">Zmazať natrvalo</button>', closeBtn('Zrušiť')));
}
export async function doGroup(o, b) {
  const gid = b.getAttribute('data-g');
  try {
    if (o === 'addGroupDo') { const n = clean(val('f-gn')); if (!n) { setErr('Napíš názov skupiny.'); return true; } await A.createGroup(n, $('f-ac').checked, $('f-ad').checked); closeSheet(); return true; }
    if (o === 'saveGroup') { const n = clean(val('f-gn')); if (!n) { setErr('Napíš názov skupiny.'); return true; } await A.updateGroup(gid, { name: n, animConfirm: $('f-ac').checked, animDocs: $('f-ad').checked }); closeSheet(); return true; }
    if (o === 'openMember') return sheetMember(b.getAttribute('data-m')), true;
    if (o === 'inviteAnim') { const t = await A.createInvite(gid); await sheetQR('invite', t); return true; }
    if (o === 'delGroup') return sheetDeleteGroup(gid), true;
    if (o === 'exportGroupG') return exportGroup(gid), true;
    if (o === 'delGroupDo') {
      const g = S.groups.find((x) => x.id === gid);
      if (clean(val('f-conf')).toLowerCase() !== clean(g.name).toLowerCase()) { setErr('Názov skupiny nesedí.'); return true; }
      lockBtn(b, true); await A.deleteGroupData(S.pid, gid); const i = b.getAttribute('data-i'); if (i) { try { await A.resolveIssue(i); } catch (e) {} }
      S.seg.pgroup = 'all'; closeSheet(); return true;
    }
  } catch (e) { lockBtn(b, false); fail(e); return true; }
  return false;
}

// ---------- farnosť: nastavenia ----------
export function sheetEditParish() {
  const p = S.parish, on = new Set(p.feasts || []);
  const list = FEAST_CATALOG.map((f) => ({ ...f, date: feastsOfYear(new Date().getFullYear()).find((x) => x.key === f.key).date }));
  openSheet('<h3>Farnosť a obdobie</h3><div class="field"><label for="f-pn">Názov farnosti</label><input id="f-pn" maxlength="100" value="' + esc(p.name) + '"></div>'
    + '<div class="field"><label for="f-ot">Tvoja funkcia</label><input id="f-ot" maxlength="40" value="' + esc(p.ownerTitle || '') + '" placeholder="napr. kaplan, farár, katechétka"></div>'
    + '<div class="field"><label for="f-from">Omše od</label><input id="f-from" type="date" value="' + p.from + '"></div><div class="field"><label for="f-to">Omše do</label><input id="f-to" type="date" value="' + p.to + '"></div>'
    + '<div class="field"><label for="f-cf">Spoveď od (mesiac)</label><input id="f-cf" type="month" value="' + p.confFrom + '"></div><div class="field"><label for="f-ct">Spoveď do (mesiac)</label><input id="f-ct" type="month" value="' + p.confTo + '"></div>'
    + '<div class="lab">Sviatky v indexe (okrem nedieľ)</div><p class="hint">Označ sviatky, na ktorých sa účasť zapisuje. Nedele sú v indexe vždy. Dátumy sa počítajú samy pre každý rok.</p>'
    + '<div class="btns"><button class="btn small plain" data-do="presetSK">Slovensko</button><button class="btn small plain" data-do="presetGEN">Všeobecné právo</button></div>'
    + '<div class="sel" style="max-height:300px">' + list.map((f) => '<label><input type="checkbox" data-feast="' + f.key + '"' + (on.has(f.key) ? ' checked' : '') + '><span>' + esc(f.name) + '</span></label>').join('') + '</div>' + errBox
    + btns('<button class="btn" data-do="saveParish">Uložiť</button>', closeBtn('Zrušiť')));
}
export async function doParish(o, b) {
  const setPreset = (k) => { const s = new Set(FEAST_PRESETS[k]); document.querySelectorAll('[data-feast]').forEach((i) => { i.checked = s.has(i.getAttribute('data-feast')); }); };
  if (o === 'presetSK') return setPreset('SK'), true;
  if (o === 'presetGEN') return setPreset('GENERAL'), true;
  if (o === 'saveParish') {
    const name = clean(val('f-pn')), from = val('f-from'), to = val('f-to'), cf = val('f-cf'), ct = val('f-ct');
    const ownerTitle = clean(val('f-ot'));
    if (ownerTitle.length < 2) { setErr('Napíš svoju funkciu.'); return true; }
    if (name.length < 2) { setErr('Napíš názov farnosti.'); return true; } if (!from || !to || from > to) { setErr('Skontroluj dátumy omší.'); return true; } if (!cf || !ct || cf > ct) { setErr('Skontroluj mesiace spovede.'); return true; }
    const feasts = [].slice.call(document.querySelectorAll('[data-feast]')).filter((i) => i.checked).map((i) => i.getAttribute('data-feast'));
    try { await A.saveParish({ name, ownerTitle, from, to, confFrom: cf, confTo: ct, feasts, preset: 'custom' }); closeSheet(); } catch (e) { fail(e); } return true;
  }
  return false;
}
export async function sheetRecovery() {
  try {
    const c = (await A.listSecrets())[0];
    openSheet('<h3>Kód obnovy správcu skupiny</h3><div class="code">' + esc(c || 'žiadny') + '</div><p class="hint">Použiješ ho spolu s kódom farnosti (' + fmtCode(S.pid) + ') na novom telefóne. Neukazuj ho nikomu.</p>'
      + btns('<button class="btn ghost" data-do="newRecovery">Vytvoriť nový kód</button>', closeBtn()));
  } catch (e) { notice('Chyba', 'Kód sa nepodarilo načítať.'); }
}
export async function newRecovery() { try { await A.newRecoveryCode(); await sheetRecovery(); } catch (e) { fail(e); } }
export function sheetDeleteParish() {
  openSheet('<h3>Zmazať farnosť?</h3><p class="hint">Natrvalo sa zmažú farnosť <b>' + esc(S.parish.name) + '</b>, všetky skupiny a údaje všetkých členov. Túto akciu nemožno vrátiť.</p><div class="field"><label for="f-conf">Pre potvrdenie napíš názov farnosti</label><input id="f-conf" autocomplete="off"></div>' + errBox
    + btns('<button class="btn danger" data-do="delParishDo">Zmazať natrvalo</button>', closeBtn('Zrušiť')));
}
export async function delParishDo(b) {
  if (clean(val('f-conf')).toLowerCase() !== clean(S.parish.name).toLowerCase()) return setErr('Názov farnosti nesedí.');
  lockBtn(b, true);
  try { await A.deleteParishData(); pstore.removeItem('ib_pid'); stopAll(); S.pid = ''; S.tab = ''; closeSheet(); requestRender(); } catch (e) { lockBtn(b, false); fail(e); }
}

// ---------- export do PDF ----------
async function groupRows(gid) {
  const members = S.members.filter((m) => m.groupId === gid && m.role === 'candidate').sort((a, b) => a.name.localeCompare(b.name, 'sk'));
  const rows = [];
  for (const m of members) {
    const r = m.status === 'pending' ? {} : await A.getRecords(m.id), ks = Object.keys(r), cnt = (p, c) => ks.filter((k) => k[0] === p && (!c || r[k].confirmed)).length;
    rows.push({ name: m.name, status: m.status, mass: cnt('m'), massC: cnt('m', 1), conf: cnt('c'), confC: cnt('c', 1), svc: cnt('s'), svcC: cnt('s', 1), gifts: cnt('g') });
  }
  return rows;
}
export async function exportGroup(gid) {
  gid = gid || (isOwner() ? null : S.me.groupId);
  if (!gid) {
    if (S.groups.length === 1) gid = S.groups[0].id;
    else return openSheet('<h3>Prehľad skupiny do PDF</h3><div class="sel">' + S.groups.map((g) => '<label><input type="radio" name="grp" value="' + g.id + '"><span>' + esc(g.name) + '</span></label>').join('') + '</div>' + errBox + btns('<button class="btn" data-do="exportGroupPick">Vytvoriť PDF</button>', closeBtn('Zrušiť')));
  }
  openSheet('<h3>Vytváram PDF…</h3><p class="hint">Môže to chvíľu trvať.</p>');
  try {
    const g = S.groups.find((x) => x.id === gid), { plan, months } = planOf(S.parish);
    await pdfGroupReport({ parish: S.parish, group: g, rows: await groupRows(gid), massTotal: plan.length, confTotal: months.length });
    closeSheet();
  } catch (e) { notice('Nepodarilo sa', 'PDF sa nepodarilo vytvoriť.'); }
}
export async function exportMember(mid) {
  const m = mid ? S.members.find((x) => x.id === mid) : S.me;
  openSheet('<h3>Vytváram PDF…</h3><p class="hint">Môže to chvíľu trvať.</p>');
  try {
    const recs = mid && mid !== S.uid ? await A.getRecords(mid) : S.records, { plan, months } = planOf(S.parish);
    await pdfCandidateIndex({ parish: S.parish, group: S.groups.find((g) => g.id === m.groupId), name: m.name, plan, months, records: recs, gifts: GIFTS, svcName });
    closeSheet();
  } catch (e) { console.error(e); notice('Nepodarilo sa', 'PDF sa nepodarilo vytvoriť.'); }
}

// ---------- chat ----------
export function sheetMsg(id) {
  const m = S.msgs.find((x) => x.id === id); if (!m) return;
  const mine = m.uid === S.uid, canDel = mine || isOwner() || isAnimator();
  openSheet('<h3>' + esc(m.name) + '</h3><p class="hint" style="color:var(--fg);font-size:15px">' + esc(m.text) + '</p>'
    + (!mine && !isOwner() ? '<div class="field"><label for="f-note">Dôvod nahlásenia (nepovinný)</label><textarea id="f-note" maxlength="300"></textarea></div>' : '') + errBox
    + btns(!mine && !isOwner() ? '<button class="btn ghost" data-do="msgReport" data-id="' + id + '">Nahlásiť správcovi skupiny</button>' : '', canDel ? '<button class="btn danger" data-do="msgDel" data-id="' + id + '">Zmazať správu</button>' : '', closeBtn()));
}
export async function doMsg(o, b) {
  const id = b.getAttribute('data-id'), m = S.msgs.find((x) => x.id === id), gid = S.chatGid || S.me.groupId;
  try {
    if (o === 'msgDel') { await A.deleteMsg(gid, id); closeSheet(); return true; }
    if (o === 'msgReport') { await A.addIssue({ type: 'report', gid, mid: id, text: m.text.slice(0, 300), targetUid: m.uid, targetName: m.name, note: clean(val('f-note')) }); notice('Nahlásené', 'Správca skupiny správu skontroluje a rozhodne.'); return true; }
  } catch (e) { fail(e); return true; }
  return false;
}
export async function sendChat() {
  const t = $('chat-in'); if (!t) return; const text = t.value.trim(); if (!text) return;
  t.value = '';
  try { await A.sendMsg(S.chatGid || S.me.groupId, text); } catch (e) { t.value = text; notice('Správa sa neodoslala', 'Skontroluj internet a skús to znova.'); }
}

// ---------- oznamy a dokumenty ----------
export function sheetAddNews() {
  const opts = isOwner() ? '<option value="all">Všetky skupiny</option>' + S.groups.map((g) => '<option value="' + g.id + '">' + esc(g.name) + '</option>').join('') : '<option value="' + S.me.groupId + '">' + esc(groupName(S.me.groupId)) + '</option>';
  openSheet('<h3>Nový oznam</h3><div class="field"><label for="f-g">Komu</label><select id="f-g">' + opts + '</select></div><div class="field"><label for="f-title">Nadpis</label><input id="f-title" maxlength="80" placeholder="napr. Zmena termínu stretnutia"></div><div class="field"><label for="f-text">Text oznamu</label><textarea id="f-text" maxlength="1000"></textarea></div>' + errBox
    + btns('<button class="btn" data-do="newsDo">Zverejniť</button>', closeBtn('Zrušiť')));
}
export function sheetNewsItem(id) {
  const n = S.news.find((x) => x.id === id); if (!n) return;
  const can = isOwner() || n.by === S.uid;
  openSheet('<h3>' + esc(n.title || 'Oznam') + '</h3><p class="hint" style="color:var(--fg);font-size:15px;white-space:pre-wrap">' + esc(n.text) + '</p><p class="hint">' + esc(n.byName) + ' · ' + fmtAt(n.at) + '</p>' + btns(can ? '<button class="btn danger" data-do="newsDel" data-id="' + id + '">Zmazať oznam</button>' : '', closeBtn()));
}
export function sheetAddDoc() {
  openSheet('<h3>Nahrať dokument</h3><p class="hint">Len PDF do ' + Math.round(A.MAX_DOC / 1000) + ' kB. Nahrávaj len veci určené pre celú skupinu, nie osobné údaje.</p><div class="field"><label for="f-title">Názov dokumentu</label><input id="f-title" maxlength="100"></div><div class="field"><label for="f-file">Súbor PDF</label><input id="f-file" type="file" accept="application/pdf"></div>' + errBox
    + btns('<button class="btn" data-do="docDo">Nahrať</button>', closeBtn('Zrušiť')));
}
export function sheetDocItem(d) {
  const can = isOwner() || d.by === S.uid;
  openSheet('<h3>' + esc(d.title) + '</h3><p class="hint">' + esc(d.byName) + ' · ' + fmtAt(d.at) + '</p>' + errBox + btns('<button class="btn" data-do="docOpen" data-id="' + d.id + '">Otvoriť / uložiť</button>', can ? '<button class="btn danger" data-do="docDel" data-id="' + d.id + '">Zmazať</button>' : '', closeBtn()));
}
export async function doNews(o, b) {
  try {
    if (o === 'newsDo') {
      const text = val('f-text').trim(), title = clean(val('f-title'));
      if (!text) { setErr('Napíš text oznamu.'); return true; }
      await A.postNews(val('f-g'), title, text); closeSheet(); return true;
    }
    if (o === 'newsDel') { await A.deleteNews(b.getAttribute('data-id')); closeSheet(); return true; }
    if (o === 'docDo') {
      const f = $('f-file').files[0], title = clean(val('f-title')) || (f ? f.name.replace(/\.pdf$/i, '') : '');
      if (!f) { setErr('Vyber súbor PDF.'); return true; }
      if (f.type !== 'application/pdf' && !/\.pdf$/i.test(f.name)) { setErr('Súbor musí byť PDF.'); return true; }
      if (f.size > A.MAX_DOC) { setErr('Súbor je príliš veľký (max ' + Math.round(A.MAX_DOC / 1000) + ' kB). Zmenši ho alebo ho pošli iným spôsobom.'); return true; }
      lockBtn(b, true); await A.uploadDoc(S.docGroup || S.me.groupId, title, f); closeSheet(); await refreshDocs(); return true;
    }
    if (o === 'docOpen') { const d = (S.docList || []).find((x) => x.id === b.getAttribute('data-id')); await A.openDoc(d); return true; }
    if (o === 'docDel') { await A.removeDoc(b.getAttribute('data-id')); closeSheet(); await refreshDocs(); return true; }
  } catch (e) { lockBtn(b, false); fail(e); return true; }
  return false;
}
export async function refreshDocs() {
  const g = S.docGroup || (S.me && S.me.groupId) || (S.groups[0] && S.groups[0].id);
  if (!g) { S.docList = []; return requestRender(); }
  S.docGroup = g; S.docList = null; requestRender();
  try { S.docList = (await A.listDocs(g)).sort((a, b) => (b.at && a.at ? (b.at.toMillis ? b.at.toMillis() : 0) - (a.at.toMillis ? a.at.toMillis() : 0) : 0)); } catch (e) { S.docList = []; }
  requestRender();
}

// ---------- na vyriešenie ----------
export function sheetIssue(id) {
  const i = S.issues.find((x) => x.id === id); if (!i) return;
  const g = groupName(i.gid);
  if (i.type === 'report') {
    return openSheet('<h3>Nahlásená správa</h3><dl class="kv"><dt>Skupina</dt><dd>' + esc(g) + '</dd><dt>Autor</dt><dd>' + esc(i.targetName) + '</dd><dt>Nahlásil</dt><dd>' + esc(i.byName) + '</dd></dl><p class="hint" style="color:var(--fg);font-size:15px">' + esc(i.text) + '</p>' + (i.note ? '<p class="hint">Dôvod: ' + esc(i.note) + '</p>' : '') + errBox
      + '<div class="btns"><button class="btn danger" data-do="isDelMsg" data-i="' + id + '">Zmazať správu</button><button class="btn ghost" data-do="isMute" data-i="' + id + '">Stlmiť autora</button><button class="btn ghost" data-do="isRemove" data-i="' + id + '">Odstrániť autora</button><button class="btn plain" data-do="isClose" data-i="' + id + '">Zavrieť bez zásahu</button></div>');
  }
  const what = i.action === 'remove_member' ? 'odstrániť člena ' + esc(i.targetName) + ' zo skupiny' : i.action === 'mute' ? 'stlmiť člena ' + esc(i.targetName) + ' v chate' : 'zmazať skupinu ' + esc(g);
  openSheet('<h3>Návrh animátora</h3><p class="hint" style="color:var(--fg);font-size:15px">' + esc(i.byName) + ' navrhuje: ' + what + '.</p>' + (i.note ? '<p class="hint">Poznámka: ' + esc(i.note) + '</p>' : '') + errBox
    + btns('<button class="btn" data-do="isApprove" data-i="' + id + '">Schváliť</button>', '<button class="btn plain" data-do="isClose" data-i="' + id + '">Zamietnuť</button>'));
}
export async function doIssue(o, b) {
  const id = b.getAttribute('data-i'), i = S.issues.find((x) => x.id === id);
  if (!i) return closeSheet(), true;
  try {
    if (o === 'isClose') { await A.resolveIssue(id); closeSheet(); return true; }
    if (o === 'isDelMsg') { try { await A.deleteMsg(i.gid, i.mid); } catch (e) {} await A.resolveIssue(id); closeSheet(); return true; }
    if (o === 'isMute') { await A.setMember(i.targetUid, { status: 'muted' }); await A.resolveIssue(id); closeSheet(); return true; }
    if (o === 'isRemove') { await A.removeMember(i.targetUid); await A.resolveIssue(id); closeSheet(); return true; }
    if (o === 'isApprove') {
      if (i.action === 'mute') await A.setMember(i.targetUid, { status: 'muted' });
      else if (i.action === 'remove_member') await A.removeMember(i.targetUid);
      else if (i.action === 'delete_group') return sheetDeleteGroup(i.gid, id), true;
      await A.resolveIssue(id); closeSheet(); return true;
    }
  } catch (e) { fail(e); return true; }
  return false;
}

export async function saveName() {
  const n = validFullName(val('f-name')); if (!n) return setErr('Napíš meno a priezvisko.');
  try { await A.setMember(S.uid, { name: n }); closeSheet(); } catch (e) { fail(e); }
}
export { openChat, closeChat };

// ---------- o aplikácii ----------
export function sheetAbout() {
  const link = (u, t) => '<a href="' + esc(u) + '" target="_blank" rel="noopener" style="color:var(--burg,#8a2646)">' + t + '</a>';
  const showSupport = SUPPORT_URL && (!Capacitor.isNativePlatform() || SUPPORT_IN_ANDROID_APP);
  openSheet('<h3>O aplikácii</h3>'
    + '<div class="card"><b>Index birmovanca</b><p class="hint">Verzia ' + esc(APP_VERSION) + '<br>Digitálny index prípravy na sviatosť birmovania, použiteľný v ktorejkoľvek farnosti a v ktoromkoľvek roku.</p></div>'
    + '<div class="card"><b>Ako to funguje</b><p class="hint">Správca skupiny (kaplan, farár, katechéta…) založí farnosť, vytvorí skupiny a pošle birmovancom QR kód. Birmovanci sa pripoja do skupiny, zapisujú si účasť na omšiach, služby, sviatosť zmierenia a 7 darov, a správca skupiny ich záznamy schváli. Animátora môže poveriť správca skupiny.</p></div>'
    + '<div class="card"><b>Čo aplikácia ponúka</b><p class="hint">Index s nedeľami a prikázanými sviatkami (kalendár sa počíta pre každý rok), oznamy a dokumenty od správcu skupiny, textový chat skupiny s moderovaním a export do PDF.</p></div>'
    + '<div class="card"><b>Ochrana údajov</b><p class="hint">Prihlásenie je anonymné, bez e-mailu a hesla. Ukladá sa len meno a priezvisko, skupina, záznamy z indexu a obsah skupiny (chat, oznamy, dokumenty). Žiadne adresy, telefónne čísla ani rodné čísla. Údaje si môžeš kedykoľvek zmazať v záložke Viac. Skupinu a jej údaje natrvalo zmaže správca skupiny po skončení prípravy.<br>' + link(LANDING_URL + 'privacy.html', 'Zásady ochrany súkromia') + '</p></div>'
    + '<div class="card"><b>Kontakt</b><p class="hint">' + esc(AUTHOR_NAME) + '<br>' + link('mailto:' + AUTHOR_EMAIL, esc(AUTHOR_EMAIL)) + '</p></div>'
    + '<div class="card"><b>Použité zdroje</b><p class="hint">Písma Montserrat a Cormorant Garamond (SIL Open Font License), DejaVu Sans, knižnice Firebase, Capacitor, jsPDF, qrcode a jsQR.</p></div>'
    + (showSupport ? '<div class="card"><b>Podporiť autora</b><p class="hint">Aplikácia je zadarmo a bez reklám. Ak ti pomáha, môžeš autora dobrovoľne podporiť.</p><a class="btn" style="display:block;text-align:center;text-decoration:none" href="' + esc(SUPPORT_URL) + '" target="_blank" rel="noopener">Podporiť autora</a></div>' : '')
    + btns(closeBtn('Zavrieť')));
}
