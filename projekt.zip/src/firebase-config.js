// ======================================================================
// NASTAVENIE FIREBASE – tieto hodnoty vyplníš podľa NAVOD-FIREBASE.md
// (Firebase konzola → Nastavenia projektu → Vaše aplikácie → Webová aplikácia → konfigurácia).
// Tieto hodnoty nie sú tajné, bezpečnosť zabezpečujú pravidlá databázy (firestore.rules).
// ======================================================================
export const firebaseConfig = {
  apiKey: 'AIzaSyDnJJWnw6PhVCK8rd1VwiXqiW7MQ9kj9pc',
  authDomain: 'index-birmovanca.firebaseapp.com',
  projectId: 'index-birmovanca',
  storageBucket: 'index-birmovanca.firebasestorage.app',
  messagingSenderId: '168626294304',
  appId: '1:168626294304:web:015de1f2b79c8b246eb645'
};

// Adresa odkazovej stránky (GitHub Pages), na ktorú smerujú QR kódy. Pozri NAVOD-FIREBASE.md, krok o GitHub Pages.
// Ak aplikácia beží ako webová stránka (napr. na Netlify), QR kódy vedú na jej vlastnú adresu.
const isWeb = typeof location !== 'undefined' && /^https?:$/.test(location.protocol) && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1';
export const LANDING_URL = isWeb ? location.origin + location.pathname.replace(/[^/]*$/, '') : 'https://emmkejjstudio.github.io/index-birmovanca/';
export const PLAY_URL = 'https://play.google.com/store/apps/details?id=sk.indexbirmovanca.app';
export const APP_SCHEME = 'indexbirmovanca';

// Dobrovoľná podpora autora (záložka Viac). Vlož odkaz na platbu (napr. PayPal.me, Buy Me a Coffee, Revolut).
// Prázdny odkaz = tlačidlo sa nezobrazí. V aplikácii z Google Play sa tlačidlo zobrazí len ak SUPPORT_IN_ANDROID_APP = true
// (Google Play obmedzuje odkazy na externé platby, preto je predvolene vypnuté).
export const SUPPORT_URL = '';
export const SUPPORT_IN_ANDROID_APP = false;
export const APP_VERSION = '1.0.0';
export const AUTHOR_NAME = 'Emmkejj Studio';
export const AUTHOR_EMAIL = 'emmkejjstudio@gmail.com';
