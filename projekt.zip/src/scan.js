// Čítanie QR kódov: kamera (getUserMedia + jsQR) alebo fotka.
import jsQR from 'jsqr';
let cur = null;
export function stopScan() { if (cur) { cur.run = false; try { cur.stream.getTracks().forEach((t) => t.stop()); } catch (e) {} cur = null; } }
export function startScan(video, onText, onError) {
  stopScan();
  if (!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) { onError('Kamera nie je dostupná. Použi tlačidlo Vybrať fotku kódu.'); return; }
  navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false }).then((stream) => {
    if (!document.body.contains(video)) { stream.getTracks().forEach((t) => t.stop()); return; }
    const me = { stream, run: true, busy: false }; cur = me;
    video.srcObject = stream; const pr = video.play(); if (pr && pr.catch) pr.catch(() => {});
    const c = document.createElement('canvas'), x = c.getContext('2d', { willReadFrequently: true });
    (function tick() {
      if (!me.run) return;
      if (!me.busy && video.readyState >= 2 && video.videoWidth) {
        const k = Math.min(1, 720 / video.videoWidth); c.width = Math.round(video.videoWidth * k); c.height = Math.round(video.videoHeight * k);
        x.drawImage(video, 0, 0, c.width, c.height);
        const img = x.getImageData(0, 0, c.width, c.height), res = jsQR(img.data, img.width, img.height, { inversionAttempts: 'dontInvert' });
        if (res && res.data) { me.busy = true; Promise.resolve(onText(res.data)).then((keep) => { if (keep) setTimeout(() => { me.busy = false; }, 2000); }); }
      }
      setTimeout(tick, 140);
    })();
  }).catch(() => onError('Aplikácia nemá povolený fotoaparát. Povoľ ho v nastaveniach telefónu alebo použi Vybrať fotku kódu.'));
}
export function scanFromFile(file) {
  return new Promise((resolve) => {
    if (!file) return resolve(null);
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const k = Math.min(1, 1400 / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      const d = x.getImageData(0, 0, c.width, c.height), res = jsQR(d.data, d.width, d.height, { inversionAttempts: 'attemptBoth' });
      resolve(res && res.data ? res.data : null);
    };
    im.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
    im.src = url;
  });
}
// Z obsahu QR kódu / odkazu vytiahne parametre p (farnosť), i (pozvánka animátora), m (kód zo sakristie)
export function parseLink(text) {
  const t = String(text || '');
  const q = t.indexOf('?') >= 0 ? t.slice(t.indexOf('?') + 1) : t;
  const out = {};
  q.replace(/#.*$/, '').split('&').forEach((kv) => { const a = kv.split('='); if (a[0]) out[a[0]] = decodeURIComponent(a[1] || ''); });
  return out.p ? { p: out.p.toUpperCase(), i: out.i || '', m: !!out.m } : null;
}
