// Tvorba PDF priamo v telefóne (jsPDF) s písmom DejaVu, aby fungovali slovenské znaky.
import { jsPDF } from 'jspdf';
import QRCode from 'qrcode';
import { bytesToBase64, deliverFile } from './files.js';

let fonts = null;
async function loadFonts() {
  if (fonts) return fonts;
  const get = async (n) => bytesToBase64(new Uint8Array(await (await fetch('fonts/' + n)).arrayBuffer()));
  fonts = { reg: await get('DejaVuSans.ttf'), bold: await get('DejaVuSans-Bold.ttf') };
  return fonts;
}
async function newDoc() {
  const f = await loadFonts();
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  doc.addFileToVFS('DejaVuSans.ttf', f.reg); doc.addFont('DejaVuSans.ttf', 'DV', 'normal');
  doc.addFileToVFS('DejaVuSans-Bold.ttf', f.bold); doc.addFont('DejaVuSans-Bold.ttf', 'DV', 'bold');
  doc.setFont('DV', 'normal');
  return doc;
}
const BURG = [138, 38, 70], GREY = [116, 99, 106], INK = [42, 26, 32];
const dmy = (s) => { const p = String(s).slice(0, 10).split('-'); return +p[2] + '. ' + +p[1] + '. ' + p[0]; };
const nowStr = () => { const d = new Date(); return d.getDate() + '. ' + (d.getMonth() + 1) + '. ' + d.getFullYear(); };

function head(doc, title, sub) {
  doc.setFont('DV', 'bold'); doc.setFontSize(18); doc.setTextColor(...BURG); doc.text(title, 15, 20);
  doc.setFont('DV', 'normal'); doc.setFontSize(10); doc.setTextColor(...GREY);
  let y = 26; (Array.isArray(sub) ? sub : [sub]).forEach((l) => { if (l) { doc.text(l, 15, y); y += 5; } });
  doc.setDrawColor(...BURG); doc.setLineWidth(0.5); doc.line(15, y, 195, y);
  doc.setTextColor(...INK);
  return y + 7;
}
function footer(doc) {
  const n = doc.getNumberOfPages();
  for (let i = 1; i <= n; i++) { doc.setPage(i); doc.setFontSize(8); doc.setTextColor(...GREY); doc.text('Index birmovanca · vytvorené ' + nowStr() + ' · strana ' + i + '/' + n, 15, 290); }
}
function table(doc, y, cols, rows) { // cols: [{h, w, a}]
  const x0 = 15, lh = 6;
  const drawHead = () => {
    doc.setFont('DV', 'bold'); doc.setFontSize(9); doc.setFillColor(...BURG); doc.setTextColor(255, 255, 255);
    doc.rect(x0, y - 4.5, 180, 7, 'F'); let x = x0 + 1.5;
    cols.forEach((c) => { doc.text(c.h, c.a === 'r' ? x + c.w - 3 : x, y, c.a === 'r' ? { align: 'right' } : {}); x += c.w; });
    doc.setFont('DV', 'normal'); doc.setTextColor(...INK); y += 7;
  };
  drawHead();
  rows.forEach((r, i) => {
    if (y > 276) { doc.addPage(); y = 20; drawHead(); }
    if (i % 2) { doc.setFillColor(246, 240, 241); doc.rect(x0, y - 4.5, 180, lh, 'F'); }
    doc.setFontSize(9); let x = x0 + 1.5;
    cols.forEach((c, k) => { const t = String(r[k] == null ? '' : r[k]); const s = doc.splitTextToSize(t, c.w - 2)[0] || ''; doc.text(s, c.a === 'r' ? x + c.w - 3 : x, y, c.a === 'r' ? { align: 'right' } : {}); x += c.w; });
    y += lh;
  });
  return y;
}
async function finish(doc, filename) {
  footer(doc);
  const b64 = doc.output('datauristring').split(',')[1];
  await deliverFile(filename, b64, 'application/pdf');
}
const slug = (s) => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w]+/g, '-').replace(/^-|-$/g, '').toLowerCase() || 'index';

// Prehľad skupiny: riadok = birmovanec, stĺpce = počty (z toho potvrdené)
export async function pdfGroupReport(o) {
  const doc = await newDoc();
  let y = head(doc, 'Prehľad skupiny: ' + o.group.name, [o.parish.name, 'Obdobie: ' + dmy(o.parish.from) + ' – ' + dmy(o.parish.to) + ' · omší v pláne: ' + o.massTotal + ' · mesiacov spovede: ' + o.confTotal]);
  const cols = [{ h: 'Meno a priezvisko', w: 66 }, { h: 'Omše', w: 28, a: 'r' }, { h: 'Spoveď', w: 28, a: 'r' }, { h: 'Služby', w: 28, a: 'r' }, { h: '7 darov', w: 30, a: 'r' }];
  const rows = o.rows.map((r) => [r.name + (r.status === 'pending' ? ' (čaká)' : ''), r.mass + ' (' + r.massC + ')', r.conf + ' (' + r.confC + ')', r.svc + ' (' + r.svcC + ')', r.gifts + ' / 7']);
  y = table(doc, y, cols, rows);
  doc.setFontSize(8.5); doc.setTextColor(...GREY); doc.text('Číslo v zátvorke = počet záznamov potvrdených správcom skupiny.', 15, y + 6);
  await finish(doc, 'prehlad-' + slug(o.group.name) + '.pdf');
}

// Index jedného birmovanca
export async function pdfCandidateIndex(o) {
  const doc = await newDoc();
  let y = head(doc, 'Index birmovanca: ' + o.name, [o.parish.name + (o.group ? ' · skupina ' + o.group.name : ''), 'Obdobie: ' + dmy(o.parish.from) + ' – ' + dmy(o.parish.to)]);
  const conf = (r) => (r && r.confirmed ? 'potvrdil ' + r.confirmed.by + ', ' + dmy(r.confirmed.at) : r ? 'čaká na potvrdenie' : '');
  const sec = (title) => { if (y > 262) { doc.addPage(); y = 20; } doc.setFont('DV', 'bold'); doc.setFontSize(12); doc.setTextColor(...BURG); doc.text(title, 15, y); doc.setTextColor(...INK); y += 3; };
  sec('Svätá omša');
  y = table(doc, y + 5, [{ h: 'Dátum', w: 28 }, { h: 'Deň / sviatok', w: 62 }, { h: 'Miesto', w: 45 }, { h: 'Potvrdenie', w: 45 }],
    o.plan.map((p) => { const r = o.records['m_' + p.date]; return [dmy(p.date), p.name || (p.kind === 'sunday' ? 'nedeľa' : ''), r ? r.place || '' : '', r ? conf(r) : 'chýba']; })) + 6;
  sec('Sviatosť zmierenia');
  y = table(doc, y + 5, [{ h: 'Mesiac', w: 28 }, { h: 'Dátum', w: 30 }, { h: 'Miesto', w: 57 }, { h: 'Potvrdenie', w: 65 }],
    o.months.map((m) => { const r = o.records['c_' + m]; return [m.slice(5) + '/' + m.slice(0, 4), r ? dmy(r.date) : '', r ? r.place || '' : '', r ? conf(r) : 'chýba']; })) + 6;
  sec('Služby pri omši a aktivity');
  const sv = Object.keys(o.records).filter((k) => k.startsWith('s_')).map((k) => o.records[k]).sort((a, b) => (a.date < b.date ? -1 : 1));
  y = table(doc, y + 5, [{ h: 'Dátum', w: 28 }, { h: 'Služba', w: 62 }, { h: 'Miesto', w: 45 }, { h: 'Potvrdenie', w: 45 }],
    sv.length ? sv.map((r) => [dmy(r.date), o.svcName(r), r.place || '', conf(r)]) : [['', 'žiadne záznamy', '', '']]) + 6;
  sec('7 darov Ducha Svätého');
  const g = o.gifts.map((n, i) => (o.records['g_' + i] ? '✓ ' : '– ') + n).join('   ');
  doc.setFontSize(9); doc.text(doc.splitTextToSize(g, 180), 15, y + 6);
  await finish(doc, 'index-' + slug(o.name) + '.pdf');
}

// Hárok s QR kódom na tlač
export async function pdfQrSheet(o) {
  const doc = await newDoc();
  doc.setFont('DV', 'bold'); doc.setFontSize(26); doc.setTextColor(...BURG); doc.text(o.title, 105, 35, { align: 'center' });
  doc.setFont('DV', 'normal'); doc.setFontSize(13); doc.setTextColor(...GREY); doc.text(o.subtitle, 105, 45, { align: 'center' });
  const png = await QRCode.toDataURL(o.url, { errorCorrectionLevel: 'M', margin: 2, width: 900 });
  doc.addImage(png, 'PNG', 40, 58, 130, 130);
  doc.setFont('DV', 'bold'); doc.setFontSize(18); doc.setTextColor(...INK); doc.text(o.heading, 105, 205, { align: 'center' });
  doc.setFont('DV', 'normal'); doc.setFontSize(13); let y = 217;
  o.steps.forEach((s, i) => { doc.text((i + 1) + '. ' + s, 105, y, { align: 'center' }); y += 9; });
  if (o.code) { doc.setFont('DV', 'bold'); doc.setFontSize(16); doc.text('Kód farnosti: ' + o.code, 105, y + 8, { align: 'center' }); }
  await finish(doc, o.filename);
}
