// Ukladanie a zdieľanie súborov: v aplikácii cez systémové okno Zdieľať, v prehliadači stiahnutím.
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export function bytesToBase64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
export function base64ToBytes(b64) {
  const s = atob(b64), a = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
  return a;
}
export async function deliverFile(filename, base64, mime) {
  if (Capacitor.isNativePlatform()) {
    const safe = filename.replace(/[^\w.\-]+/g, '_');
    const r = await Filesystem.writeFile({ path: safe, data: base64, directory: Directory.Cache });
    await Share.share({ title: filename, url: r.uri, dialogTitle: 'Uložiť alebo poslať súbor' });
    return;
  }
  const blob = new Blob([base64ToBytes(base64)], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
}
export function readFileBase64(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => { const s = String(fr.result); res(s.slice(s.indexOf(',') + 1)); };
    fr.onerror = () => rej(new Error('read'));
    fr.readAsDataURL(file);
  });
}
