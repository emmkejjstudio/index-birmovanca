// Cirkevný kalendár pre ľubovoľný rok (gregoriánsky): nedele, pevné a pohyblivé sviatky.
// Zoznam prikázaných sviatkov na Slovensku vychádza z prehľadu Tlačovej kancelárie KBS
// (tkkbs.sk, „Prehľad cirkevne prikázaných a pohyblivých sviatkov"): 1.1., 6.1., Veľkonočná nedeľa,
// Nanebovstúpenie Pána, Božie telo, 29.6., 15.8., 1.11., 8.12., 25.12.

const pad = (n) => (n < 10 ? '0' : '') + n;
export const iso = (y, m, d) => y + '-' + pad(m) + '-' + pad(d);

// Veľká noc (Gaussov/Meeusov algoritmus pre gregoriánsky kalendár)
export function easter(y) {
  const a = y % 19, b = Math.floor(y / 100), c = y % 100;
  const d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3), h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31), day = ((h + l - 7 * m + 114) % 31) + 1;
  return { y, m: month, d: day };
}
// dátum posunutý o n dní (bez časových pásiem: počítame cez UTC poludnie)
export function addDays(s, n) {
  const p = s.split('-').map(Number);
  const t = new Date(Date.UTC(p[0], p[1] - 1, p[2], 12));
  t.setUTCDate(t.getUTCDate() + n);
  return iso(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate());
}
export function weekdayOf(s) { // 0 = nedeľa
  const p = s.split('-').map(Number);
  return new Date(Date.UTC(p[0], p[1] - 1, p[2], 12)).getUTCDay();
}

// Katalóg sviatkov: key, názov, pravidlo. fixed = [mesiac, deň]; rel = dni od Veľkej noci.
export const FEAST_CATALOG = [
  { key: 'bohorodicka', name: 'Panny Márie Bohorodičky', fixed: [1, 1] },
  { key: 'zjavenie', name: 'Zjavenie Pána', fixed: [1, 6] },
  { key: 'jozef', name: 'Sv. Jozefa', fixed: [3, 19] },
  { key: 'zvestovanie', name: 'Zvestovanie Pána', fixed: [3, 25] },
  { key: 'popolcova', name: 'Popolcová streda', rel: -46 },
  { key: 'velky_stvrtok', name: 'Zelený štvrtok', rel: -3 },
  { key: 'velky_piatok', name: 'Veľký piatok', rel: -2 },
  { key: 'biela_sobota', name: 'Biela sobota', rel: -1 },
  { key: 'velka_noc', name: 'Veľkonočná nedeľa', rel: 0 },
  { key: 'velkonocny_pondelok', name: 'Veľkonočný pondelok', rel: 1 },
  { key: 'nanebovstupenie', name: 'Nanebovstúpenie Pána', rel: 39 },
  { key: 'zoslanie', name: 'Zoslanie Ducha Svätého', rel: 49 },
  { key: 'bozie_telo', name: 'Najsvätejšieho Kristovho Tela a Krvi (Božie telo)', rel: 60 },
  { key: 'cyril_metod', name: 'Sv. Cyrila a Metoda', fixed: [7, 5] },
  { key: 'petra_pavla', name: 'Sv. Petra a Pavla', fixed: [6, 29] },
  { key: 'nanebovzatie', name: 'Nanebovzatie Panny Márie', fixed: [8, 15] },
  { key: 'sedembolestna', name: 'Panny Márie Sedembolestnej', fixed: [9, 15] },
  { key: 'vsetkych_svatych', name: 'Všetkých svätých', fixed: [11, 1] },
  { key: 'zadusky', name: 'Pamiatka zosnulých', fixed: [11, 2] },
  { key: 'neposkvrnene', name: 'Nepoškvrnené počatie Panny Márie', fixed: [12, 8] },
  { key: 'narodenie', name: 'Narodenie Pána', fixed: [12, 25] },
  { key: 'stefan', name: 'Sv. Štefana', fixed: [12, 26] }
];

// Predvolené zoznamy prikázaných sviatkov. Kaplan ich môže v nastaveniach farnosti upraviť.
export const FEAST_PRESETS = {
  SK: ['bohorodicka', 'zjavenie', 'velka_noc', 'nanebovstupenie', 'bozie_telo', 'petra_pavla', 'nanebovzatie', 'vsetkych_svatych', 'neposkvrnene', 'narodenie'],
  GENERAL: ['bohorodicka', 'zjavenie', 'jozef', 'velka_noc', 'nanebovstupenie', 'bozie_telo', 'petra_pavla', 'nanebovzatie', 'vsetkych_svatych', 'neposkvrnene', 'narodenie']
};
export const PRESET_LABELS = { SK: 'Slovensko (prehľad KBS)', GENERAL: 'Všeobecné právo Cirkvi' };

export function feastDate(f, y) {
  if (f.fixed) return iso(y, f.fixed[0], f.fixed[1]);
  const e = easter(y);
  return addDays(iso(e.y, e.m, e.d), f.rel);
}

// Všetky sviatky roku: [{date, key, name}] zoradené podľa dátumu.
export function feastsOfYear(y) {
  return FEAST_CATALOG.map((f) => ({ date: feastDate(f, y), key: f.key, name: f.name }))
    .sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
}

// Názov špeciálnej nedele (advent, Kvetná, Kristus Kráľ ...). Inak null.
export function sundayName(s) {
  const y = +s.slice(0, 4);
  const e = easter(y), es = iso(e.y, e.m, e.d);
  if (s === addDays(es, -7)) return 'Kvetná nedeľa';
  if (s === es) return 'Veľkonočná nedeľa';
  if (s === addDays(es, 7)) return 'Nedeľa Božieho milosrdenstva';
  if (s === addDays(es, 49)) return 'Zoslanie Ducha Svätého';
  if (s === addDays(es, 56)) return 'Najsvätejšej Trojice';
  // adventné nedele: 4 nedele pred 25.12. (vrátane nedele, ak je 24.12.)
  const xmas = iso(y, 12, 25), wd = weekdayOf(xmas);
  const lastAdv = addDays(xmas, -(wd === 0 ? 7 : wd)); // štvrtá adventná
  for (let i = 0; i < 4; i++) if (s === addDays(lastAdv, -7 * i)) return (4 - i) + '. adventná nedeľa';
  if (s === addDays(lastAdv, -28)) return 'Nedeľa Krista Kráľa';
  const holy = weekdayOf(xmas) === 0 ? iso(y, 12, 30) : addDays(xmas, 7 - weekdayOf(xmas)); // sv. rodina
  if (s === holy) return 'Sviatok Svätej rodiny';
  return null;
}

// Zoznam dní pre index: nedele + vybrané sviatky v období [from, to] (ISO dátumy).
// enabledKeys = sviatky, ktoré sa majú v indexe zobrazovať (typicky prikázané).
export function planMasses(from, to, enabledKeys) {
  const on = new Set(enabledKeys || []);
  const out = {};
  const y0 = +from.slice(0, 4), y1 = +to.slice(0, 4);
  for (let y = y0; y <= y1; y++) {
    for (const f of feastsOfYear(y)) {
      if (on.has(f.key) && f.date >= from && f.date <= to) out[f.date] = { date: f.date, name: f.name, kind: 'feast' };
    }
  }
  let d = from;
  while (weekdayOf(d) !== 0) d = addDays(d, 1);
  for (; d <= to; d = addDays(d, 7)) {
    const sn = sundayName(d);
    if (out[d]) { out[d].sunday = true; if (sn && !out[d].name) out[d].name = sn; }
    else out[d] = { date: d, name: sn || '', kind: 'sunday' };
  }
  return Object.values(out).sort((a, b) => (a.date < b.date ? -1 : 1));
}

// Predvolené obdobie prípravy pre školský rok začínajúci v roku y: 1. 9. y až 30. 6. y+1.
export function defaultPeriod(y) { return { from: iso(y, 9, 1), to: iso(y + 1, 6, 30) }; }
// Mesiace obdobia pre sviatosť zmierenia: zoznam kľúčov 'RRRR-MM' od from po to.
export function monthsBetween(from, to) {
  const out = [];
  let y = +from.slice(0, 4), m = +from.slice(5, 7);
  const ye = +to.slice(0, 4), me = +to.slice(5, 7);
  while (y < ye || (y === ye && m <= me)) { out.push(y + '-' + pad(m)); m++; if (m > 12) { m = 1; y++; } }
  return out;
}
