export const $ = (id) => document.getElementById(id);
export const pad2 = (n) => (n < 10 ? '0' : '') + n;
export const iso = (y, m, d) => y + '-' + pad2(m) + '-' + pad2(d);
export const MONTHS = ['Január', 'Február', 'Marec', 'Apríl', 'Máj', 'Jún', 'Júl', 'August', 'September', 'Október', 'November', 'December'];
export const SHORT = ['jan', 'feb', 'mar', 'apr', 'máj', 'jún', 'júl', 'aug', 'sep', 'okt', 'nov', 'dec'];
export function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
export function todayISO() { const d = new Date(); return iso(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
export function parts(s) { const a = s.split('-'); return { y: +a[0], m: +a[1], d: +a[2] }; }
export function weekday(s) { const p = parts(s); try { return new Date(p.y, p.m - 1, p.d).toLocaleDateString('sk-SK', { weekday: 'long' }); } catch (e) { return ''; } }
export function longDate(s) { const p = parts(String(s).slice(0, 10)); return p.d + '. ' + p.m + '. ' + p.y; }
export function tms(x) { if (!x) return 0; if (typeof x.toMillis === 'function') return x.toMillis(); const t = Date.parse(x); return isNaN(t) ? 0 : t; }
export function fmtAt(x) { const t = tms(x); if (!t) return ''; const d = new Date(t); return d.getDate() + '. ' + (d.getMonth() + 1) + '. ' + d.getFullYear() + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()); }
export function fmtTime(x) { const t = tms(x); if (!t) return ''; const d = new Date(t); const n = new Date(); const hm = pad2(d.getHours()) + ':' + pad2(d.getMinutes()); return d.toDateString() === n.toDateString() ? hm : d.getDate() + '. ' + (d.getMonth() + 1) + '. ' + hm; }
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
export function randCode(n) { const a = new Uint32Array(n); crypto.getRandomValues(a); let s = ''; for (let i = 0; i < n; i++) s += ALPHA[a[i] % ALPHA.length]; return s; }
export function randToken() { return randCode(20); }
export function fmtCode(c) { return String(c).replace(/(.{4})(?=.)/g, '$1-'); }
export function normCode(s) { return String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, ''); }
export function validFullName(n) { n = String(n || '').trim().replace(/\s+/g, ' '); return n.length >= 3 && n.length <= 60 && n.indexOf(' ') > 0 ? n : null; }
export function clean(s) { return String(s || '').trim().replace(/\s+/g, ' '); }

// Uloženie id farnosti: v testovacom režime po kartách, inak trvalo v telefóne.
export const pstore = (typeof __MOCK__ !== 'undefined' && __MOCK__) ? sessionStorage : localStorage;
