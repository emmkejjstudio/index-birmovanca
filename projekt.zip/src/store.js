// Spoločný stav aplikácie a odbery údajov (reálny čas).
import { db, doc, onSnapshot, query, where, orderBy, limit, pRef, col, dref } from './fb.js';
import { planMasses, monthsBetween } from './calendar.js';
import { tms, pstore } from './util.js';

export const S = {
  uid: null, pid: pstore.getItem('ib_pid') || '', parish: null, me: undefined, groups: [], members: [], issues: [], news: [], records: {},
  lastMsg: null, msgs: [], chatGid: null, tab: '', seg: {}, gone: '', loading: true, err: ''
};
export const hooks = { render: () => {}, chat: () => {} };
let unsubs = [], roleKey = '', roleUnsubs = [], chatUnsub = null;
let raf = 0;
export function requestRender() { if (raf) return; raf = requestAnimationFrame(() => { raf = 0; hooks.render(); }); }

export function stopAll() {
  unsubs.forEach((u) => u()); unsubs = []; stopRole(); stopChat();
  Object.assign(S, { parish: null, me: undefined, groups: [], members: [], issues: [], news: [], records: {}, lastMsg: null, msgs: [], chatGid: null });
  roleKey = '';
}
function stopRole() { roleUnsubs.forEach((u) => u()); roleUnsubs = []; }
function stopChat() { if (chatUnsub) chatUnsub(); chatUnsub = null; }
const err = (e) => { console.error(e); S.err = 'Spojenie s databázou zlyhalo. Skontroluj internet.'; requestRender(); };

export function startParish(pid) {
  stopAll();
  S.pid = pid; S.gone = ''; S.loading = true; pstore.setItem('ib_pid', pid);
  unsubs.push(onSnapshot(pRef(pid), (s) => { S.parish = s.exists() ? { id: pid, ...s.data() } : null; if (!s.exists() && S.me !== undefined) S.gone = 'Farnosť už neexistuje.'; requestRender(); }, err));
  unsubs.push(onSnapshot(dref(pid, 'members', S.uid), (s) => {
    const prev = S.me;
    S.me = s.exists() ? { id: S.uid, ...s.data() } : null;
    S.loading = false;
    const key = S.me ? S.me.role + '|' + S.me.status + '|' + S.me.groupId : '';
    if (key !== roleKey) { roleKey = key; subscribeRole(); }
    if (prev && !S.me) S.gone = 'Tvoj záznam vo farnosti už neexistuje (správca skupiny ťa odstránil alebo si údaje zmazal).';
    requestRender();
  }, err));
  unsubs.push(onSnapshot(col(pid, 'groups'), (s) => { S.groups = s.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => a.name.localeCompare(b.name, 'sk')); requestRender(); }, err));
}

function subscribeRole() {
  stopRole();
  const me = S.me, pid = S.pid;
  if (!me) return;
  const mapDocs = (s) => s.docs.map((d) => ({ id: d.id, ...d.data() }));
  if (me.role === 'owner') {
    roleUnsubs.push(onSnapshot(col(pid, 'members'), (s) => { S.members = mapDocs(s); requestRender(); }, err));
    roleUnsubs.push(onSnapshot(query(col(pid, 'issues'), orderBy('at', 'desc'), limit(100)), (s) => { S.issues = mapDocs(s); requestRender(); }, err));
    roleUnsubs.push(onSnapshot(query(col(pid, 'news'), orderBy('at', 'desc'), limit(60)), (s) => { S.news = mapDocs(s); requestRender(); }, err));
  } else if (me.role === 'animator' && me.status === 'active') {
    roleUnsubs.push(onSnapshot(query(col(pid, 'members'), where('groupId', '==', me.groupId)), (s) => { S.members = mapDocs(s); requestRender(); }, err));
    roleUnsubs.push(onSnapshot(query(col(pid, 'news'), where('gid', 'in', [me.groupId, 'all'])), (s) => { S.news = mapDocs(s).sort((a, b) => tms(b.at) - tms(a.at)); requestRender(); }, err));
    watchLast(me.groupId);
  } else if (me.role === 'candidate' && (me.status === 'active' || me.status === 'muted')) {
    roleUnsubs.push(onSnapshot(col(pid, 'members', S.uid, 'records'), (s) => { const r = {}; s.docs.forEach((d) => { r[d.id] = d.data(); }); S.records = r; requestRender(); }, err));
    roleUnsubs.push(onSnapshot(query(col(pid, 'news'), where('gid', 'in', [me.groupId, 'all'])), (s) => { S.news = mapDocs(s).sort((a, b) => tms(b.at) - tms(a.at)); requestRender(); }, err));
    watchLast(me.groupId);
  }
}
function watchLast(gid) {
  roleUnsubs.push(onSnapshot(query(col(S.pid, 'groups', gid, 'messages'), orderBy('at', 'desc'), limit(1)), (s) => {
    S.lastMsg = s.docs.length ? { ...s.docs[0].data(), id: s.docs[0].id } : null; requestRender();
  }, () => {}));
}

// chat otvorenej skupiny
export function openChat(gid) {
  stopChat(); S.chatGid = gid; S.msgs = [];
  markSeen(gid);
  chatUnsub = onSnapshot(query(col(S.pid, 'groups', gid, 'messages'), orderBy('at', 'desc'), limit(100)), (s) => {
    S.msgs = s.docs.map((d) => ({ id: d.id, ...d.data() })).reverse();
    markSeen(gid); hooks.chat();
  }, err);
}
export function closeChat() { stopChat(); S.chatGid = null; S.msgs = []; }
export function markSeen(gid) { try { localStorage.setItem('ib_seen_' + S.pid + '_' + gid, String(Date.now())); } catch (e) {} }
export function unreadChat() {
  if (!S.me || S.me.role === 'owner' || !S.lastMsg || !S.me.groupId) return false;
  if (S.lastMsg.uid === S.uid) return false;
  let seen = 0; try { seen = +localStorage.getItem('ib_seen_' + S.pid + '_' + S.me.groupId) || 0; } catch (e) {}
  return tms(S.lastMsg.at) > seen;
}

// pomocné odvodené údaje
let planCache = { k: '', plan: [], months: [] };
export function planOf(p) {
  const k = [p.from, p.to, p.confFrom, p.confTo, (p.feasts || []).join(',')].join('|');
  if (planCache.k !== k) planCache = { k, plan: planMasses(p.from, p.to, p.feasts || []), months: monthsBetween(p.confFrom, p.confTo) };
  return planCache;
}
export const isOwner = () => S.me && S.me.role === 'owner';
export const isAnimator = () => S.me && S.me.role === 'animator';
export const isCandidate = () => S.me && S.me.role === 'candidate';
export const myGroup = () => S.groups.find((g) => S.me && g.id === S.me.groupId);
export const groupName = (gid) => { const g = S.groups.find((x) => x.id === gid); return g ? g.name : 'bez skupiny'; };
