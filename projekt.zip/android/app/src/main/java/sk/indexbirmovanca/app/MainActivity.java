package sk.indexbirmovanca.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
