import json, subprocess, time, sys, os, re
from playwright.sync_api import sync_playwright
ROOT='/home/claude/ibp-app/www-test'; SCR='/tmp/claude-0/-home-claude/395d9709-29e5-5192-8a19-b747cee68fe5/scratchpad/shots/'
os.makedirs(SCR,exist_ok=True)
srv=subprocess.Popen(['python3','-m','http.server','8771','--directory',ROOT],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
time.sleep(1); B='http://localhost:8771/'
errs=[]; res={}
def newpage(ctx,name):
    pg=ctx.new_page(); pg.on('pageerror',lambda e:(errs.append((name,str(e))),print('PAGEERROR',name,str(e)[:300],flush=True))); pg.on('console',lambda m: (errs.append((name,'console:'+m.text)),print('CONSOLE',name,m.text[:300],flush=True)) if m.type=='error' else None); return pg
def S(pg,expr): return pg.evaluate('()=>window.__ib.S.'+expr)
def db(pg): return json.loads(pg.evaluate("localStorage.getItem('mockdb')") or '{}')
def shot(pg,n): pg.screenshot(path=SCR+n+'.png')
PAGES=[]
def step(name,fn):
    for q in [x for x in PAGES]:
        try: q.keyboard.press('Escape')
        except Exception: pass
    try: fn(); res[name]='ok'
    except Exception as e: res[name]='FAIL '+str(e)[:300]; print('FAIL',name,str(e)[:400]); 
try:
  with sync_playwright() as p:
    br=p.chromium.launch(executable_path='/opt/pw-browsers/chromium',args=['--no-sandbox'])
    ctx=br.new_context(viewport={'width':400,'height':820},service_workers='block',accept_downloads=True)
    ctx.set_default_timeout(6000); ow=newpage(ctx,'owner'); PAGES.append(ow); ow.goto(B); ow.wait_for_selector('text=Zakladám farnosť')
    shot(ow,'01_welcome')
    def s_setup():
        ow.click('text=Zakladám farnosť'); ow.fill('#f-pn','Farnosť Všetkých svätých, Humenné'); ow.fill('#f-name','Ján Kaplan'); ow.fill('#f-ot','farár')
        shot(ow,'02_setup'); ow.click('#sheet button:has-text("Založiť farnosť")'); ow.wait_for_selector('text=Farnosť je založená')
        res['recovery_sheet']=ow.inner_text('#sheet')[:200]; ow.click('text=Rozumiem')
        ow.wait_for_selector('text=Index birmovanca')
    step('owner_setup',s_setup)
    pid=S(ow,'pid'); res['pid']=pid
    def s_groups():
        ow.click('main >> text=Vytvoriť skupinu'); ow.fill('#f-gn','Skupina A'); ow.check('#f-ac'); ow.click('#sheet button:has-text("Vytvoriť")'); ow.wait_for_selector('.row:has-text("Skupina A")',timeout=3000) if False else None
        ow.wait_for_timeout(300)
        ow.click('nav.tabs >> text=Farnosť'); ow.click('text=Pridať skupinu'); ow.fill('#f-gn','Skupina B'); ow.click('#sheet button:has-text("Vytvoriť")'); ow.wait_for_timeout(300)
        shot(ow,'03_parish')
        assert 'Skupina A' in ow.inner_text('main') and 'Skupina B' in ow.inner_text('main')
    step('groups',s_groups)
    # kandidát
    ca=newpage(ctx,'cand'); ca.goto(B+'?p='+pid)
    def s_join():
        ca.wait_for_selector('text=Pripojiť sa'.replace('Pripojiť sa','Odoslať žiadosť'),timeout=5000)
        ca.check('input[name=grp] >> nth=0'); ca.fill('#f-name','Jana Nováková'); shot(ca,'04_join'); ca.click('#sheet button:has-text("Odoslať žiadosť")')
        ca.wait_for_selector('text=Čakáš na potvrdenie'); shot(ca,'05_pending')
    step('cand_join',s_join)
    def s_confirm():
        ow.click('nav.tabs >> text=Ľudia'); ow.wait_for_selector('text=Jana Nováková'); shot(ow,'06_people')
        ow.click('.row:has-text("Jana Nováková")'); ow.wait_for_selector('button:has-text("Potvrdiť pripojenie")'); ow.click('button:has-text("Potvrdiť pripojenie")')
        ca.wait_for_selector('nav.tabs >> text=Index',timeout=5000); shot(ca,'07_cand_index')
    step('owner_confirms_join',s_confirm)
    def s_mass():
        ca.click('.row.today'); ca.fill('#f-place','Humenné'); ca.click('#sheet button:has-text("Bol som na omši")'); ca.wait_for_selector('.row.today .chip.wait')
        shot(ca,'08_mass')
    step('cand_mass_manual',s_mass)
    def s_qr():
        ca.goto(B+'?p='+pid+'&m=1'); ca.wait_for_selector('text=Účasť zapísaná'.replace('Účasť zapísaná','Účasť zapísaná') ,timeout=5000) if False else ca.wait_for_timeout(1500)
        res['qr_sheet']=ca.inner_text('#sheet')[:120] if ca.is_visible('#sheet') else 'nosheet'
    step('cand_mass_qr',s_qr)

    def s_conf_rec():
        ow.click('nav.tabs >> text=Ľudia'); ow.click('.row:has-text("Jana Nováková")'); ow.wait_for_selector('text=Čaká na potvrdenie (1)')
        shot(ow,'09_member'); ow.click('#sheet button:has-text("Potvrdiť vybrané")'); ow.wait_for_selector('text=Všetky záznamy sú potvrdené')
        ca.wait_for_selector('.row.today .chip.ok',timeout=5000); ow.click('#sheet button:has-text("Zavrieť")')
    step('owner_confirms_records',s_conf_rec)
    def s_chat():
        ca.keyboard.press('Escape')
        ca.click('nav.tabs >> text=Chat'); ca.fill('#chat-in','Ahoj, kedy je stretnutie?'); ca.click('button:has-text("Poslať")'); ca.wait_for_selector('.msg.mine')
        ow.click('nav.tabs >> text=Chat'); ow.click('.row:has-text("Skupina A")'); ow.wait_for_selector('.msg:has-text("kedy je stretnutie")')
        ow.fill('#chat-in','V piatok o 17:00.'); ow.click('button:has-text("Poslať")'); ca.wait_for_selector('.msg:has-text("V piatok")'); shot(ca,'10_chat')
    step('chat_roundtrip',s_chat)
    def s_report():
        ca.click('.msg:has-text("V piatok")'); ca.fill('#f-note','test'); ca.click('#sheet button:has-text("Nahlásiť")'); ca.wait_for_selector('text=Nahlásené'); ca.click('#sheet button:has-text("Zavrieť")')
        ow.click('nav.tabs >> text=Riešiť'); ow.wait_for_selector('.row:has-text("Nahlásená správa")'); ow.click('.row:has-text("Nahlásená správa")'); shot(ow,'11_issue')
        ow.click('#sheet button:has-text("Zmazať správu")'); ow.wait_for_selector('text=Nič nečaká na vyriešenie')
        ow.click('nav.tabs >> text=Chat'); ow.click('.row:has-text("Skupina A")'); ow.wait_for_selector('.msg:has-text("kedy je stretnutie")'); assert 'V piatok' not in ow.inner_text('#chatbox')
    step('report_and_delete_msg',s_report)
    # animátor
    def s_anim():
        ow.click('nav.tabs >> text=Farnosť'); ow.click('.row:has-text("Skupina A")'); ow.click('#sheet button:has-text("Pozvať animátora")'); ow.wait_for_selector('.qrimg'); shot(ow,'12_invite_qr')
        inv=[k for k in db(ow) if '/invites/' in k][0].split('/')[-1]; res['invite']=inv; ow.click('#sheet button:has-text("Zavrieť")')
        global an
        an=newpage(ctx,'anim'); PAGES.append(an); an.goto(B+'?p='+pid+'&i='+inv); an.wait_for_selector('text=Animátor: Skupina A'); an.fill('#f-name','Peter Animátor'); an.click('#sheet button:has-text("Pripojiť sa")')
        an.wait_for_selector('nav.tabs >> text=Skupina'); shot(an,'13_anim'); res['anim_text']=an.inner_text('main')[:200]
        assert not [k for k in db(ow) if '/invites/' in k]
    step('animator_join',s_anim)
    def s_anim_perm():
        an.click('.row:has-text("Jana Nováková")'); an.wait_for_selector('text=Navrhnúť správcovi skupiny'); an.click('#sheet button:has-text("Navrhnúť správcovi skupiny")'); an.select_option('#f-act','mute'); an.fill('#f-note','spamuje')
        an.click('#sheet button:has-text("Poslať správcovi skupiny")'); an.wait_for_selector('text=Odoslané'); an.click('#sheet button:has-text("Zavrieť")')
        ow.click('nav.tabs >> text=Riešiť'); ow.click('.row:has-text("Návrh")'); shot(ow,'14_proposal'); ow.click('#sheet button:has-text("Schváliť")'); ow.wait_for_selector('text=Nič nečaká')
        ca.wait_for_selector('text=Si dočasne stlmený'); 
        ow.click('nav.tabs >> text=Ľudia'); ow.click('.row:has-text("Jana Nováková")'); ow.click('#sheet button:has-text("Zrušiť stlmenie")')
    step('animator_proposal_mute',s_anim_perm)
    def s_news_docs():
        ow.click('nav.tabs >> text=Oznamy'); ow.click('main >> text=Nový oznam'); ow.select_option('#f-g','all'); ow.fill('#f-title','Zmena termínu'); ow.fill('#f-text','Stretnutie je posunuté na sobotu.'); ow.click('#sheet button:has-text("Zverejniť")')
        ca.click('nav.tabs >> text=Oznamy'); ca.wait_for_selector('.row:has-text("Zmena termínu")'); shot(ca,'15_news')
        pdf=SCR+'t.pdf'; open(pdf,'wb').write(b'%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF')
        ow.click('main >> button[data-seg="news|docs"]'); ow.wait_for_selector('main >> text=Nahrať PDF'); ow.click('main >> text=Nahrať PDF'); ow.fill('#f-title','Rozpis stretnutí'); ow.set_input_files('#f-file',pdf); ow.click('#sheet button:has-text("Nahrať")')
        ow.wait_for_selector('.row:has-text("Rozpis stretnutí")')
        ca.click('main >> button[data-seg="news|docs"]'); ca.wait_for_selector('.row:has-text("Rozpis stretnutí")'); shot(ca,'16_docs')
        ca.click('.row:has-text("Rozpis stretnutí")')
        with ca.expect_download() as d: ca.click('#sheet button:has-text("Otvoriť")')
        res['doc_dl']=d.value.suggested_filename
    step('news_and_docs',s_news_docs)
    def s_pdf():
        ow.click('nav.tabs >> text=Ľudia'); 
        ow.click('main >> text=Prehľad skupiny do PDF'); ow.check('input[name=grp] >> nth=0')
        with ow.expect_download(timeout=20000) as d: ow.click('#sheet button:has-text("Vytvoriť PDF")')
        d.value.save_as(SCR+'prehlad.pdf'); res['pdf1']=d.value.suggested_filename
        ow.click('.row:has-text("Jana Nováková")')
        with ow.expect_download(timeout=20000) as d2: ow.click('#sheet button:has-text("Index do PDF")')
        d2.value.save_as(SCR+'index.pdf'); res['pdf2']=d2.value.suggested_filename
    step('pdf_exports',s_pdf)
    def s_qrpdf():
        ow.keyboard.press('Escape'); ow.click('nav.tabs >> text=Farnosť'); ow.click('main >> text=QR kód do sakristie'); ow.wait_for_selector('.qrimg')
        with ow.expect_download(timeout=20000) as d: ow.click('#sheet button:has-text("Hárok na tlač")')
        d.value.save_as(SCR+'qr.pdf'); res['pdf3']=d.value.suggested_filename; ow.keyboard.press('Escape')
    step('qr_pdf',s_qrpdf)
    def s_delgroup():
        ow.click('.row:has-text("Skupina A")'); ow.click('#sheet button:has-text("Zmazať skupinu")'); ow.fill('#f-conf','Skupina A'); ow.click('#sheet button:has-text("Zmazať natrvalo")'); ow.wait_for_timeout(500)
        left=[k for k in db(ow) if 'members/' in k and not k.endswith(S(ow,'uid'))]; res['left_after_group_delete']=left
        assert not [k for k in db(ow) if '/groups/' in k and 'Skupina A' in json.dumps(db(ow)[k])]
        ca.wait_for_selector('text=už neexistuje',timeout=5000); shot(ca,'17_gone')
    step('delete_group_wipes_members',s_delgroup)
    def s_restore():
        sec=[k for k in db(ow) if '/secrets/' in k][0].split('/')[-1]
        nw=newpage(ctx,'new'); nw.goto(B); nw.click('text=Mám kód obnovy'); nw.fill('#f-code',pid); nw.fill('#f-rec',sec); nw.fill('#f-name','Ján Kaplan'); nw.click('#sheet button:has-text("Obnoviť")'); nw.wait_for_selector('nav.tabs >> text=Farnosť'); res['restored']='ok'
    step('owner_restore',s_restore)
    def s_delparish():
        ow.click('nav.tabs >> text=Farnosť'); ow.click('main button:has-text("Zmazať farnosť")'); ow.fill('#f-conf','Farnosť Všetkých svätých, Humenné'); ow.click('#sheet button:has-text("Zmazať natrvalo")'); ow.wait_for_selector('text=Zakladám farnosť'); 
        assert not [k for k in db(ow) if k.startswith('parishes/'+pid)], [k for k in db(ow) if k.startswith('parishes/'+pid)]
    step('delete_parish',s_delparish)
    json.dump({'res':res,'errs':errs},open(SCR+'out.json','w'),ensure_ascii=False,indent=1)
    print(json.dumps(res,ensure_ascii=False,indent=1)); print('ERRS',errs[:10])
    br.close()
finally: srv.terminate()
