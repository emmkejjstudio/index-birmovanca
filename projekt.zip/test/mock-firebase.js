// Testovacie úložisko namiesto Firebase (len na lokálne testy). Dáta sú v localStorage, takže ich vidia
// aj iné karty tej istej relácie prehliadača; identita používateľa je v sessionStorage (každá karta = iný používateľ).
const K = 'mockdb';
const load = () => { try { return JSON.parse(localStorage.getItem(K) || '{}'); } catch (e) { return {}; } };
const save = (db) => localStorage.setItem(K, JSON.stringify(db));
const listeners = new Set();
const notify = () => listeners.forEach((f) => f());
window.addEventListener('storage', (e) => { if (e.key === K) notify(); });

export class Timestamp {
  constructor(ms) { this.ms = ms; }
  toMillis() { return this.ms; }
  toDate() { return new Date(this.ms); }
  static fromMillis(ms) { return new Timestamp(ms); }
  static now() { return new Timestamp(Date.now()); }
}
const SERVER = { __sentinel: 'server' };
const DEL = { __sentinel: 'delete' };
export const serverTimestamp = () => SERVER;
export const deleteField = () => DEL;
const resolve = (data, base) => {
  const out = { ...(base || {}) };
  for (const k of Object.keys(data)) {
    const v = data[k];
    if (v === SERVER) out[k] = { __ts: Date.now() };
    else if (v === DEL) delete out[k];
    else out[k] = v;
  }
  return out;
};
const revive = (o) => {
  if (o && typeof o === 'object' && !Array.isArray(o)) {
    if ('__ts' in o) return new Timestamp(o.__ts);
    const r = {}; for (const k of Object.keys(o)) r[k] = revive(o[k]); return r;
  }
  return o;
};

export function initializeApp() { return {}; }
export function getApps() { return []; }
const auth = { currentUser: null };
export function getAuth() { return auth; }
export function signInAnonymously(a) {
  let uid = sessionStorage.getItem('mock_uid');
  if (!uid) { uid = 'u' + Math.random().toString(36).slice(2, 10); sessionStorage.setItem('mock_uid', uid); }
  a.currentUser = { uid };
  return Promise.resolve({ user: a.currentUser });
}
export function onAuthStateChanged(a, cb) { Promise.resolve().then(() => cb(a.currentUser)); return () => {}; }
export function initializeFirestore() { return { __db: true }; }
export function getFirestore() { return { __db: true }; }
export function persistentLocalCache() { return {}; }

const join = (parts) => parts.filter((p) => typeof p === 'string').join('/');
export function collection(base, ...seg) { const path = base.path ? base.path + '/' + join(seg) : join(seg); return { type: 'collection', path, id: path.split('/').pop() }; }
export function doc(base, ...seg) {
  let path;
  if (base.type === 'collection') path = seg.length ? base.path + '/' + join(seg) : base.path + '/' + 'd' + Math.random().toString(36).slice(2, 12);
  else path = base.path ? base.path + '/' + join(seg) : join(seg);
  return { type: 'doc', path, id: path.split('/').pop() };
}
const snapOf = (path, db) => ({
  id: path.split('/').pop(), ref: { type: 'doc', path, id: path.split('/').pop() },
  exists: () => path in db, data: () => (path in db ? revive(db[path]) : undefined)
});
export const getDoc = async (ref) => snapOf(ref.path, load());
export const setDoc = async (ref, data, opts) => { const db = load(); db[ref.path] = resolve(data, opts && opts.merge ? db[ref.path] : {}); save(db); notify(); };
export const updateDoc = async (ref, data) => { const db = load(); if (!(ref.path in db)) throw new Error('no doc'); db[ref.path] = resolve(data, db[ref.path]); save(db); notify(); };
export const deleteDoc = async (ref) => { const db = load(); delete db[ref.path]; save(db); notify(); };
export const where = (field, op, value) => ({ t: 'where', field, op, value });
export const orderBy = (field, dir) => ({ t: 'order', field, dir: dir || 'asc' });
export const limit = (n) => ({ t: 'limit', n });
export const query = (coll, ...cons) => ({ type: 'query', coll, cons });
const val = (v) => (v && typeof v === 'object' && '__ts' in v ? v.__ts : v);
function run(q) {
  const db = load();
  const coll = q.type === 'query' ? q.coll : q, cons = q.type === 'query' ? q.cons : [];
  let res = Object.keys(db).filter((p) => p.startsWith(coll.path + '/') && !p.slice(coll.path.length + 1).includes('/'));
  cons.filter((c) => c.t === 'where').forEach((c) => {
    res = res.filter((p) => {
      const v = val(db[p][c.field]);
      if (c.op === '==') return v === c.value || (c.value === null && v == null);
      if (c.op === '!=') return v !== c.value;
      if (c.op === 'in') return c.value.includes(v);
      return true;
    });
  });
  const ob = cons.find((c) => c.t === 'order');
  if (ob) res.sort((a, b) => { const x = val(db[a][ob.field]), y = val(db[b][ob.field]); return (x > y ? 1 : x < y ? -1 : 0) * (ob.dir === 'desc' ? -1 : 1); });
  const lm = cons.find((c) => c.t === 'limit'); if (lm) res = res.slice(0, lm.n);
  const docs = res.map((p) => snapOf(p, db));
  return { docs, empty: !docs.length, size: docs.length, forEach: (f) => docs.forEach(f) };
}
export const getDocs = async (q) => run(q);
export function onSnapshot(ref, cb) {
  const fire = () => { if (ref.type === 'doc') cb(snapOf(ref.path, load())); else cb(run(ref)); };
  const f = () => Promise.resolve().then(fire);
  listeners.add(f); f();
  return () => listeners.delete(f);
}
export function writeBatch() {
  const ops = [];
  const b = {
    set: (ref, data, opts) => { ops.push(() => { const db = load(); db[ref.path] = resolve(data, opts && opts.merge ? db[ref.path] : {}); save(db); }); return b; },
    update: (ref, data) => { ops.push(() => { const db = load(); db[ref.path] = resolve(data, db[ref.path]); save(db); }); return b; },
    delete: (ref) => { ops.push(() => { const db = load(); delete db[ref.path]; save(db); }); return b; },
    commit: async () => { ops.forEach((o) => o()); notify(); }
  };
  return b;
}
