# Návod: od nuly po aplikáciu v Google Play

Postupuj krok za krokom. Nič nemusíš programovať.

## 1. Firebase (databáza aplikácie), asi 15 minút
1. Choď na https://console.firebase.google.com a prihlás sa účtom Emmkejj Studio.
2. **Add project** → názov `index-birmovanca` → Google Analytics vypni → **Create project**.
3. Vľavo **Build → Authentication → Get started → Sign-in method → Anonymous → Enable → Save**.
4. Vľavo **Build → Firestore Database → Create database**. Vyber región `eur3 (europe-west)` (najbližšie k Slovensku), režim **Production**. Create.
5. V Firestore otvor záložku **Rules**, zmaž všetko, vlož celý obsah súboru `firestore.rules` z tohto balíka a daj **Publish**.
6. Ozubené koliesko → **Project settings → General → Your apps → ikona `</>` (Web)**. Názov `index-birmovanca`, Hosting nezapínaj → **Register app**.
7. Zobrazí sa blok `firebaseConfig`. Otvor `src/firebase-config.js` a nahraď hodnoty `DOPLN_*` (apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId). Tieto hodnoty nie sú tajné, bezpečnosť zabezpečujú pravidlá z kroku 5.
8. **Dôležité:** v Authentication → Settings → Authorized domains nič netreba. Aplikácia beží z Androidu.
9. Odporúčanie: v Google Cloud Console (APIs & Services → Credentials) obmedz API kľúč na Android aplikáciu `sk.indexbirmovanca.app`. Nie je to nutné.

Cena: stačí bezplatný plán Spark. Aplikácia nepoužíva Cloud Functions ani Storage, preto nepotrebuje platený plán. Dokumenty (PDF) sa ukladajú do databázy a môžu mať do 650 kB.

## 2. GitHub (zostavenie aplikácie), asi 15 minút
1. Na https://github.com (účet `emmkejjstudio`) vytvor **nový repozitár** `index-birmovanca`, verejný.
2. Nahraj doň všetok obsah tohto balíka (tlačidlo *Add file → Upload files*, môžeš pretiahnuť celý priečinok, vrátane skrytého priečinka `.github`). Ak nahrávanie `.github` nejde cez web, vytvor súbory ručne cez *Add file → Create new file* s cestou `.github/workflows/build.yml` a skopíruj obsah.
3. **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main, folder: /docs → Save.** Po minúte bude fungovať `https://emmkejjstudio.github.io/index-birmovanca/` (úvodná stránka pre QR kódy) a `.../privacy.html` (zásady súkromia pre Google Play).
4. Ak sa tvoje používateľské meno alebo názov repozitára líši, uprav `LANDING_URL` v `src/firebase-config.js`.

## 3. Podpisový kľúč (len raz)
1. V repozitári **Actions → Vytvoriť podpisový kľúč (len raz) → Run workflow**.
2. Keď dobehne, otvor ho a stiahni výsledok **podpisovy-kluc-ZALOHUJ-A-ZMAZ**. Obsahuje `release.jks`, `release.jks.b64` a `hesla.txt`.
3. **Zálohuj** `release.jks` a `hesla.txt` na bezpečné miesto mimo GitHubu (bez nich nepôjde aplikáciu nikdy aktualizovať). Nikomu ich neposielaj.
4. V repozitári **Settings → Secrets and variables → Actions → New repository secret** vytvor štyri tajomstvá:
   - `KEYSTORE_BASE64` = celý obsah súboru `release.jks.b64`
   - `KEYSTORE_PASSWORD` = hodnota z `hesla.txt`
   - `KEY_ALIAS` = `indexbirmovanca`
   - `KEY_PASSWORD` = hodnota z `hesla.txt`
5. Artefakt potom na GitHube zmaž (Actions → beh → Delete artifact).

## 4. Zostavenie aplikácie
1. **Actions → Zostaviť aplikáciu → Run workflow.** Trvá asi 6 až 10 minút.
2. Na konci stiahni artefakty: `index-birmovanca-ladiaca-apk` (na skúšku do telefónu) a `index-birmovanca-release-aab` (do Google Play).
3. Každý ďalší beh automaticky zvýši číslo verzie.

## 5. Google Play Console
1. Play Console → **Create app** → názov *Index birmovanca*, jazyk slovenčina, App, Free.
2. Texty z `PLAY-LISTING.md`, ikona 512×512 je v `src/icons/icon-512.png`. Screenshoty urob z telefónu (min. 2).
3. **Policy → App content**: Privacy policy = `https://emmkejjstudio.github.io/index-birmovanca/privacy.html`; Data safety a Content rating podľa `PLAY-LISTING.md`; Target audience; Ads = No.
4. **Testing → Closed testing** → vytvor track, nahraj `.aab`, pridaj aspoň **12 testerov** (e-maily Google účtov). Musia ostať prihlásení **14 dní v kuse**, až potom môžeš žiadať o produkciu.
5. Potom **Production → Apply for production** a po schválení vydaj.

## Bežný chod aplikácie
- Kaplan: *Som kaplan* → zadá názov farnosti a obdobie → vytvorí skupiny → ukáže birmovancom QR kód. Kód obnovy si zapíše (pri výmene telefónu ho zadá cez *Mám kód obnovy*).
- Birmovanec: naskenuje QR (alebo zadá kód farnosti), nainštaluje aplikáciu, vyberie skupinu a zadá meno. Kaplan ho potvrdí.

## Upozornenia a obmedzenia
- Aplikácia neposiela push oznámenia (vyžadujú platený plán Firebase). Chat a oznamy sa zobrazia po otvorení aplikácie, nové správy sa označujú číslom.
- Identita je anonymná: ak birmovanec vymaže údaje aplikácie alebo ju odinštaluje, musí sa pripojiť znova. Kaplan to rieši kódom obnovy.
- Pravidlá databázy (`firestore.rules`) sa nepodarilo otestovať emulátorom. Po nastavení Firebase si ich vyskúšaj na dvoch telefónoch (viď kontrolný zoznam nižšie).

## Kontrolný zoznam skúšky na 2 telefónoch
1. Telefón A: založ farnosť, vytvor skupinu, ukáž QR.
2. Telefón B: nainštaluj APK, naskenuj QR, pripoj sa. Na A potvrď.
3. B zapíše omšu, A ju potvrdí. Skús chat, oznam, nahratie PDF.
4. Ak niečo hlási "Nemáš oprávnenie", napíš mi presnú hlášku, upravím pravidlá.
