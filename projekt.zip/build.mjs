// Zbalí src/main.js a štýly do www/app.js a www/app.css. Prepínač --mock použije testovacie úložisko namiesto Firebase.
import { build } from 'esbuild';
import { cpSync, mkdirSync, rmSync } from 'node:fs';
const mock = process.argv.includes('--mock');
const out = mock ? 'www-test' : 'www';
rmSync(out, { recursive: true, force: true });
mkdirSync(out + '/fonts', { recursive: true });
const alias = mock ? { 'firebase/app': './test/mock-firebase.js', 'firebase/auth': './test/mock-firebase.js', 'firebase/firestore': './test/mock-firebase.js' } : {};
await build({
  entryPoints: { app: 'src/main.js' },
  bundle: true, minify: !mock, sourcemap: mock, format: 'iife', target: ['chrome90'],
  outdir: out, alias, logLevel: 'warning',
  define: { __MOCK__: String(mock) },
  loader: { '.woff2': 'file', '.woff': 'empty' }, assetNames: 'assets/[name]-[hash]'
});
cpSync('src/index.html', out + '/index.html');
cpSync('src/icons', out + '/icons', { recursive: true });
cpSync('docs/privacy.html', out + '/privacy.html');
cpSync('node_modules/dejavu-fonts-ttf/ttf/DejaVuSans.ttf', out + '/fonts/DejaVuSans.ttf');
cpSync('node_modules/dejavu-fonts-ttf/ttf/DejaVuSans-Bold.ttf', out + '/fonts/DejaVuSans-Bold.ttf');
console.log('hotovo →', out);
